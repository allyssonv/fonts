package br.gov.empresa.arquitetura.application.usecase.classificacao;

import br.gov.empresa.arquitetura.domain.exception.RecursoNaoEncontradoException;
import br.gov.empresa.arquitetura.domain.model.ArquiteturaReferencia;
import br.gov.empresa.arquitetura.domain.model.ClassificacaoArquitetural;
import br.gov.empresa.arquitetura.domain.model.enums.NivelAderencia;
import br.gov.empresa.arquitetura.domain.repository.ArquiteturaReferenciaRepository;
import br.gov.empresa.arquitetura.domain.repository.ClassificacaoArquiteturalRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ConsultarSistemasPorArquiteturaUseCaseTest {

    @Mock ArquiteturaReferenciaRepository arquiteturaRepository;
    @Mock ClassificacaoArquiteturalRepository classificacaoRepository;

    @InjectMocks
    ConsultarSistemasPorArquiteturaUseCase useCase;

    @Test
    void deveRetornarClassificacoesParaArquiteturaExistente() {
        UUID arquiteturaId = UUID.randomUUID();
        ArquiteturaReferencia arquitetura = new ArquiteturaReferencia();
        arquitetura.setId(arquiteturaId);
        ClassificacaoArquitetural c = new ClassificacaoArquitetural();
        c.setArquiteturaId(arquiteturaId);
        c.setNivelAderencia(NivelAderencia.ADERENTE);
        when(arquiteturaRepository.buscarPorId(arquiteturaId)).thenReturn(Optional.of(arquitetura));
        when(classificacaoRepository.listarPorArquiteturaId(arquiteturaId)).thenReturn(List.of(c));

        List<ClassificacaoArquitetural> resultado = useCase.executar(arquiteturaId);

        assertThat(resultado).hasSize(1);
    }

    @Test
    void deveLancarExcecaoQuandoArquiteturaNaoExiste() {
        UUID arquiteturaId = UUID.randomUUID();
        when(arquiteturaRepository.buscarPorId(arquiteturaId)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> useCase.executar(arquiteturaId))
                .isInstanceOf(RecursoNaoEncontradoException.class);
    }
}
