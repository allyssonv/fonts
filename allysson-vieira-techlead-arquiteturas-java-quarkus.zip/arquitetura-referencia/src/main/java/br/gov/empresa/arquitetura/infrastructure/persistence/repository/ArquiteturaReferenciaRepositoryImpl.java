package br.gov.empresa.arquitetura.infrastructure.persistence.repository;

import br.gov.empresa.arquitetura.domain.model.ArquiteturaReferencia;
import br.gov.empresa.arquitetura.domain.model.enums.StatusArquitetura;
import br.gov.empresa.arquitetura.domain.repository.ArquiteturaReferenciaRepository;
import br.gov.empresa.arquitetura.infrastructure.persistence.entity.ArquiteturaReferenciaEntity;
import br.gov.empresa.arquitetura.infrastructure.persistence.mapper.ArquiteturaReferenciaMapper;
import io.quarkus.hibernate.orm.panache.PanacheRepositoryBase;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@ApplicationScoped
public class ArquiteturaReferenciaRepositoryImpl
        implements ArquiteturaReferenciaRepository, PanacheRepositoryBase<ArquiteturaReferenciaEntity, UUID> {

    @Inject
    ArquiteturaReferenciaMapper mapper;

    @Override
    @Transactional
    public ArquiteturaReferencia salvar(ArquiteturaReferencia arquitetura) {
        ArquiteturaReferenciaEntity entity = mapper.toEntity(arquitetura);
        if (entity.getId() == null) {
            persist(entity);
        } else {
            entity = getEntityManager().merge(entity);
        }
        return mapper.toDomain(entity);
    }

    @Override
    public Optional<ArquiteturaReferencia> buscarPorId(UUID id) {
        return findByIdOptional(id).map(mapper::toDomain);
    }

    @Override
    public List<ArquiteturaReferencia> listarTodas() {
        return listAll().stream().map(mapper::toDomain).toList();
    }

    @Override
    public boolean existeNomeAtivo(String nome) {
        return count("nome = ?1 and status = ?2", nome, StatusArquitetura.ATIVA) > 0;
    }

    @Override
    public boolean existeNomeAtivoComIdDiferente(String nome, UUID id) {
        return count("nome = ?1 and status = ?2 and id != ?3", nome, StatusArquitetura.ATIVA, id) > 0;
    }
}
