package br.gov.empresa.arquitetura.infrastructure.persistence.mapper;

import br.gov.empresa.arquitetura.domain.model.ClassificacaoArquitetural;
import br.gov.empresa.arquitetura.infrastructure.persistence.entity.ClassificacaoArquiteturalEntity;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class ClassificacaoArquiteturalMapper {

    public ClassificacaoArquitetural toDomain(ClassificacaoArquiteturalEntity entity) {
        if (entity == null) return null;
        ClassificacaoArquitetural domain = new ClassificacaoArquitetural();
        domain.setId(entity.getId());
        domain.setSistemaId(entity.getSistemaId());
        domain.setArquiteturaId(entity.getArquiteturaId());
        domain.setNivelAderencia(entity.getNivelAderencia());
        domain.setJustificativa(entity.getJustificativa());
        domain.setResponsavelAvaliacao(entity.getResponsavelAvaliacao());
        domain.setDataAvaliacao(entity.getDataAvaliacao());
        return domain;
    }

    public ClassificacaoArquiteturalEntity toEntity(ClassificacaoArquitetural domain) {
        if (domain == null) return null;
        ClassificacaoArquiteturalEntity entity = new ClassificacaoArquiteturalEntity();
        entity.setId(domain.getId());
        entity.setSistemaId(domain.getSistemaId());
        entity.setArquiteturaId(domain.getArquiteturaId());
        entity.setNivelAderencia(domain.getNivelAderencia());
        entity.setJustificativa(domain.getJustificativa());
        entity.setResponsavelAvaliacao(domain.getResponsavelAvaliacao());
        entity.setDataAvaliacao(domain.getDataAvaliacao());
        return entity;
    }
}
