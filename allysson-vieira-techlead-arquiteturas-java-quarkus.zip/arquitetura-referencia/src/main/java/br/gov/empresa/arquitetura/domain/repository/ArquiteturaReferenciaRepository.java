package br.gov.empresa.arquitetura.domain.repository;

import br.gov.empresa.arquitetura.domain.model.ArquiteturaReferencia;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface ArquiteturaReferenciaRepository {

    ArquiteturaReferencia salvar(ArquiteturaReferencia arquitetura);

    Optional<ArquiteturaReferencia> buscarPorId(UUID id);

    List<ArquiteturaReferencia> listarTodas();

    boolean existeNomeAtivo(String nome);

    boolean existeNomeAtivoComIdDiferente(String nome, UUID id);
}
