package br.gov.empresa.arquitetura.domain.model;

import br.gov.empresa.arquitetura.domain.model.enums.StatusArquitetura;
import br.gov.empresa.arquitetura.domain.model.enums.TipoArquitetura;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

public class ArquiteturaReferencia {

    private UUID id;
    private String nome;
    private String descricao;
    private TipoArquitetura tipo;
    private StatusArquitetura status;
    private List<Tecnologia> tecnologiasRecomendadas;
    private LocalDateTime dataCriacao;
    private LocalDateTime dataAtualizacao;

    public ArquiteturaReferencia() {
        this.tecnologiasRecomendadas = new ArrayList<>();
    }

    public boolean isAtiva() {
        return StatusArquitetura.ATIVA.equals(this.status);
    }

    public void inativar() {
        this.status = StatusArquitetura.INATIVA;
        this.dataAtualizacao = LocalDateTime.now();
    }

    public List<Tecnologia> getTecnologiasRecomendadas() {
        return Collections.unmodifiableList(tecnologiasRecomendadas);
    }

    public void setTecnologiasRecomendadas(List<Tecnologia> tecnologias) {
        this.tecnologiasRecomendadas = tecnologias != null ? new ArrayList<>(tecnologias) : new ArrayList<>();
    }

    public UUID getId() { return id; }
    public String getNome() { return nome; }
    public String getDescricao() { return descricao; }
    public TipoArquitetura getTipo() { return tipo; }
    public StatusArquitetura getStatus() { return status; }
    public LocalDateTime getDataCriacao() { return dataCriacao; }
    public LocalDateTime getDataAtualizacao() { return dataAtualizacao; }

    public void setId(UUID id) { this.id = id; }
    public void setNome(String nome) { this.nome = nome; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public void setTipo(TipoArquitetura tipo) { this.tipo = tipo; }
    public void setStatus(StatusArquitetura status) { this.status = status; }
    public void setDataCriacao(LocalDateTime dataCriacao) { this.dataCriacao = dataCriacao; }
    public void setDataAtualizacao(LocalDateTime dataAtualizacao) { this.dataAtualizacao = dataAtualizacao; }
}
