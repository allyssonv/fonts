package br.gov.empresa.arquitetura.infrastructure.persistence.entity;

import br.gov.empresa.arquitetura.domain.model.enums.StatusArquitetura;
import br.gov.empresa.arquitetura.domain.model.enums.TipoArquitetura;
import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "arquitetura_referencia")
public class ArquiteturaReferenciaEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false, unique = true)
    private String nome;

    @Column(columnDefinition = "TEXT")
    private String descricao;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TipoArquitetura tipo;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatusArquitetura status;

    @OneToMany(mappedBy = "arquitetura", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private List<TecnologiaEntity> tecnologiasRecomendadas = new ArrayList<>();

    @Column(nullable = false)
    private LocalDateTime dataCriacao;

    private LocalDateTime dataAtualizacao;

    public UUID getId() { return id; }
    public String getNome() { return nome; }
    public String getDescricao() { return descricao; }
    public TipoArquitetura getTipo() { return tipo; }
    public StatusArquitetura getStatus() { return status; }
    public List<TecnologiaEntity> getTecnologiasRecomendadas() { return tecnologiasRecomendadas; }
    public LocalDateTime getDataCriacao() { return dataCriacao; }
    public LocalDateTime getDataAtualizacao() { return dataAtualizacao; }

    public void setId(UUID id) { this.id = id; }
    public void setNome(String nome) { this.nome = nome; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public void setTipo(TipoArquitetura tipo) { this.tipo = tipo; }
    public void setStatus(StatusArquitetura status) { this.status = status; }
    public void setTecnologiasRecomendadas(List<TecnologiaEntity> tecnologias) { this.tecnologiasRecomendadas = tecnologias; }
    public void setDataCriacao(LocalDateTime dataCriacao) { this.dataCriacao = dataCriacao; }
    public void setDataAtualizacao(LocalDateTime dataAtualizacao) { this.dataAtualizacao = dataAtualizacao; }
}
