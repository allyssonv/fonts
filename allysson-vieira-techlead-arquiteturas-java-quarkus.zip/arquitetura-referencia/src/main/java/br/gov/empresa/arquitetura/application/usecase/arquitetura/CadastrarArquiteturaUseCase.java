package br.gov.empresa.arquitetura.application.usecase.arquitetura;

import br.gov.empresa.arquitetura.domain.exception.ConflitoUnicidadeException;
import br.gov.empresa.arquitetura.domain.model.ArquiteturaReferencia;
import br.gov.empresa.arquitetura.domain.model.enums.StatusArquitetura;
import br.gov.empresa.arquitetura.domain.repository.ArquiteturaReferenciaRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.time.LocalDateTime;

@ApplicationScoped
public class CadastrarArquiteturaUseCase {

    @Inject
    ArquiteturaReferenciaRepository repository;

    public ArquiteturaReferencia executar(ArquiteturaReferencia arquitetura) {
        if (repository.existeNomeAtivo(arquitetura.getNome())) {
            throw new ConflitoUnicidadeException(
                    "Já existe uma arquitetura de referência ativa com o nome: " + arquitetura.getNome());
        }

        arquitetura.setStatus(StatusArquitetura.ATIVA);
        arquitetura.setDataCriacao(LocalDateTime.now());
        arquitetura.setDataAtualizacao(LocalDateTime.now());

        return repository.salvar(arquitetura);
    }
}
