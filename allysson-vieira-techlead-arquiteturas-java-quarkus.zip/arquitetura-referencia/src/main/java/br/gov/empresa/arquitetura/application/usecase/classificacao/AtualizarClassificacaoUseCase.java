package br.gov.empresa.arquitetura.application.usecase.classificacao;

import br.gov.empresa.arquitetura.domain.exception.RecursoNaoEncontradoException;
import br.gov.empresa.arquitetura.domain.exception.RegraDeNegocioException;
import br.gov.empresa.arquitetura.domain.model.ClassificacaoArquitetural;
import br.gov.empresa.arquitetura.domain.model.enums.NivelAderencia;
import br.gov.empresa.arquitetura.domain.repository.ClassificacaoArquiteturalRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.time.LocalDateTime;
import java.util.UUID;

@ApplicationScoped
public class AtualizarClassificacaoUseCase {

    @Inject
    ClassificacaoArquiteturalRepository repository;

    public ClassificacaoArquitetural executar(UUID id, ClassificacaoArquitetural dados) {
        ClassificacaoArquitetural existente = repository.buscarPorId(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException(
                        "Classificação arquitetural não encontrada com id: " + id));

        validarJustificativa(dados.getNivelAderencia(), dados.getJustificativa());

        existente.setNivelAderencia(dados.getNivelAderencia());
        existente.setJustificativa(dados.getJustificativa());
        existente.setResponsavelAvaliacao(dados.getResponsavelAvaliacao());
        existente.setDataAvaliacao(LocalDateTime.now());

        return repository.salvar(existente);
    }

    private void validarJustificativa(NivelAderencia nivel, String justificativa) {
        if ((NivelAderencia.PARCIALMENTE_ADERENTE.equals(nivel) || NivelAderencia.NAO_ADERENTE.equals(nivel))
                && (justificativa == null || justificativa.isBlank())) {
            throw new RegraDeNegocioException(
                    "Justificativa é obrigatória para níveis PARCIALMENTE_ADERENTE e NAO_ADERENTE.");
        }
    }
}
