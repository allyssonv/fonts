package br.gov.empresa.arquitetura.infrastructure.persistence.entity;

import br.gov.empresa.arquitetura.domain.model.enums.NivelAderencia;
import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "classificacao_arquitetural")
public class ClassificacaoArquiteturalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "sistema_id", nullable = false)
    private UUID sistemaId;

    @Column(name = "arquitetura_id", nullable = false)
    private UUID arquiteturaId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private NivelAderencia nivelAderencia;

    @Column(columnDefinition = "TEXT")
    private String justificativa;

    @Column(nullable = false)
    private String responsavelAvaliacao;

    @Column(nullable = false)
    private LocalDateTime dataAvaliacao;

    public UUID getId() { return id; }
    public UUID getSistemaId() { return sistemaId; }
    public UUID getArquiteturaId() { return arquiteturaId; }
    public NivelAderencia getNivelAderencia() { return nivelAderencia; }
    public String getJustificativa() { return justificativa; }
    public String getResponsavelAvaliacao() { return responsavelAvaliacao; }
    public LocalDateTime getDataAvaliacao() { return dataAvaliacao; }

    public void setId(UUID id) { this.id = id; }
    public void setSistemaId(UUID sistemaId) { this.sistemaId = sistemaId; }
    public void setArquiteturaId(UUID arquiteturaId) { this.arquiteturaId = arquiteturaId; }
    public void setNivelAderencia(NivelAderencia nivelAderencia) { this.nivelAderencia = nivelAderencia; }
    public void setJustificativa(String justificativa) { this.justificativa = justificativa; }
    public void setResponsavelAvaliacao(String responsavelAvaliacao) { this.responsavelAvaliacao = responsavelAvaliacao; }
    public void setDataAvaliacao(LocalDateTime dataAvaliacao) { this.dataAvaliacao = dataAvaliacao; }
}
