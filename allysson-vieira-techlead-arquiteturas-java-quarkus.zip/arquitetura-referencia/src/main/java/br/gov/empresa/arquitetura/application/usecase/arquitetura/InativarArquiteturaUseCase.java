package br.gov.empresa.arquitetura.application.usecase.arquitetura;

import br.gov.empresa.arquitetura.domain.exception.RecursoNaoEncontradoException;
import br.gov.empresa.arquitetura.domain.exception.RegraDeNegocioException;
import br.gov.empresa.arquitetura.domain.model.ArquiteturaReferencia;
import br.gov.empresa.arquitetura.domain.repository.ArquiteturaReferenciaRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.UUID;

@ApplicationScoped
public class InativarArquiteturaUseCase {

    @Inject
    ArquiteturaReferenciaRepository repository;

    public ArquiteturaReferencia executar(UUID id) {
        ArquiteturaReferencia arquitetura = repository.buscarPorId(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException(
                        "Arquitetura de referência não encontrada com id: " + id));

        if (!arquitetura.isAtiva()) {
            throw new RegraDeNegocioException("Arquitetura de referência já está inativa.");
        }

        arquitetura.inativar();
        return repository.salvar(arquitetura);
    }
}
