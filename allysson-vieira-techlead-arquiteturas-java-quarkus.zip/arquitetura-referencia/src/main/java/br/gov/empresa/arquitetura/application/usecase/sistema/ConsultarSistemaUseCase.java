package br.gov.empresa.arquitetura.application.usecase.sistema;

import br.gov.empresa.arquitetura.domain.exception.RecursoNaoEncontradoException;
import br.gov.empresa.arquitetura.domain.model.SistemaCorporativo;
import br.gov.empresa.arquitetura.domain.repository.SistemaCorporativoRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.List;
import java.util.UUID;

@ApplicationScoped
public class ConsultarSistemaUseCase {

    @Inject
    SistemaCorporativoRepository repository;

    public SistemaCorporativo buscarPorId(UUID id) {
        return repository.buscarPorId(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException(
                        "Sistema corporativo não encontrado com id: " + id));
    }

    public List<SistemaCorporativo> listarTodos() {
        return repository.listarTodos();
    }

    public List<SistemaCorporativo> listarSemClassificacao() {
        return repository.listarSemClassificacao();
    }
}
