package br.gov.empresa.arquitetura.infrastructure.persistence.mapper;

import br.gov.empresa.arquitetura.domain.model.ArquiteturaReferencia;
import br.gov.empresa.arquitetura.domain.model.Tecnologia;
import br.gov.empresa.arquitetura.infrastructure.persistence.entity.ArquiteturaReferenciaEntity;
import br.gov.empresa.arquitetura.infrastructure.persistence.entity.TecnologiaEntity;
import jakarta.enterprise.context.ApplicationScoped;

import java.util.List;

@ApplicationScoped
public class ArquiteturaReferenciaMapper {

    public ArquiteturaReferencia toDomain(ArquiteturaReferenciaEntity entity) {
        if (entity == null) return null;
        ArquiteturaReferencia domain = new ArquiteturaReferencia();
        domain.setId(entity.getId());
        domain.setNome(entity.getNome());
        domain.setDescricao(entity.getDescricao());
        domain.setTipo(entity.getTipo());
        domain.setStatus(entity.getStatus());
        domain.setDataCriacao(entity.getDataCriacao());
        domain.setDataAtualizacao(entity.getDataAtualizacao());

        if (entity.getTecnologiasRecomendadas() != null) {
            List<Tecnologia> tecnologias = entity.getTecnologiasRecomendadas().stream()
                    .map(this::tecToDomain)
                    .toList();
            domain.setTecnologiasRecomendadas(tecnologias);
        }
        return domain;
    }

    public ArquiteturaReferenciaEntity toEntity(ArquiteturaReferencia domain) {
        if (domain == null) return null;
        ArquiteturaReferenciaEntity entity = new ArquiteturaReferenciaEntity();
        entity.setId(domain.getId());
        entity.setNome(domain.getNome());
        entity.setDescricao(domain.getDescricao());
        entity.setTipo(domain.getTipo());
        entity.setStatus(domain.getStatus());
        entity.setDataCriacao(domain.getDataCriacao());
        entity.setDataAtualizacao(domain.getDataAtualizacao());

        if (domain.getTecnologiasRecomendadas() != null) {
            List<TecnologiaEntity> tecnologias = domain.getTecnologiasRecomendadas().stream()
                    .map(t -> tecToEntity(t, entity))
                    .toList();
            entity.setTecnologiasRecomendadas(tecnologias);
        }
        return entity;
    }

    private Tecnologia tecToDomain(TecnologiaEntity entity) {
        return new Tecnologia(entity.getId(), entity.getNome(), entity.getCategoria(),
                entity.getVersaoRecomendada(), entity.getSituacaoUso(), entity.getObservacoes());
    }

    private TecnologiaEntity tecToEntity(Tecnologia domain, ArquiteturaReferenciaEntity arquitetura) {
        TecnologiaEntity entity = new TecnologiaEntity();
        entity.setId(domain.getId());
        entity.setNome(domain.getNome());
        entity.setCategoria(domain.getCategoria());
        entity.setVersaoRecomendada(domain.getVersaoRecomendada());
        entity.setSituacaoUso(domain.getSituacaoUso());
        entity.setObservacoes(domain.getObservacoes());
        entity.setArquitetura(arquitetura);
        return entity;
    }
}
