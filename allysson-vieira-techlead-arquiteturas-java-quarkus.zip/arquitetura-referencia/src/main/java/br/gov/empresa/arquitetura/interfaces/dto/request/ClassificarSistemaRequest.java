package br.gov.empresa.arquitetura.interfaces.dto.request;

import br.gov.empresa.arquitetura.domain.model.enums.NivelAderencia;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.UUID;

public record ClassificarSistemaRequest(
        @NotNull(message = "ID do sistema é obrigatório")
        UUID sistemaId,

        @NotNull(message = "ID da arquitetura é obrigatório")
        UUID arquiteturaId,

        @NotNull(message = "Nível de aderência é obrigatório")
        NivelAderencia nivelAderencia,

        String justificativa,

        @NotBlank(message = "Responsável pela avaliação é obrigatório")
        String responsavelAvaliacao
) {}
