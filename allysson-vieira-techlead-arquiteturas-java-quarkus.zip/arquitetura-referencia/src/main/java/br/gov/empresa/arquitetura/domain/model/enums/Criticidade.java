package br.gov.empresa.arquitetura.domain.model.enums;

public enum Criticidade {
    CRITICA,
    ALTA,
    MEDIA,
    BAIXA
}
