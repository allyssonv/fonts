package br.gov.empresa.arquitetura.application.usecase.arquitetura;

import br.gov.empresa.arquitetura.domain.exception.ConflitoUnicidadeException;
import br.gov.empresa.arquitetura.domain.model.ArquiteturaReferencia;
import br.gov.empresa.arquitetura.domain.model.enums.StatusArquitetura;
import br.gov.empresa.arquitetura.domain.model.enums.TipoArquitetura;
import br.gov.empresa.arquitetura.domain.repository.ArquiteturaReferenciaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CadastrarArquiteturaUseCaseTest {

    @Mock
    ArquiteturaReferenciaRepository repository;

    @InjectMocks
    CadastrarArquiteturaUseCase useCase;

    ArquiteturaReferencia arquitetura;

    @BeforeEach
    void setUp() {
        arquitetura = new ArquiteturaReferencia();
        arquitetura.setNome("Microsserviços Cloud");
        arquitetura.setDescricao("Arquitetura baseada em microsserviços");
        arquitetura.setTipo(TipoArquitetura.MICROSSERVICOS);
    }

    @Test
    void deveCadastrarArquiteturaComSucesso() {
        when(repository.existeNomeAtivo(arquitetura.getNome())).thenReturn(false);
        ArquiteturaReferencia salva = new ArquiteturaReferencia();
        salva.setId(UUID.randomUUID());
        salva.setNome(arquitetura.getNome());
        salva.setStatus(StatusArquitetura.ATIVA);
        when(repository.salvar(any())).thenReturn(salva);

        ArquiteturaReferencia resultado = useCase.executar(arquitetura);

        assertThat(resultado).isNotNull();
        assertThat(resultado.getId()).isNotNull();
        verify(repository).salvar(any());
    }

    @Test
    void deveLancarExcecaoQuandoNomeJaExiste() {
        when(repository.existeNomeAtivo(arquitetura.getNome())).thenReturn(true);

        assertThatThrownBy(() -> useCase.executar(arquitetura))
                .isInstanceOf(ConflitoUnicidadeException.class)
                .hasMessageContaining("Microsserviços Cloud");

        verify(repository, never()).salvar(any());
    }

    @Test
    void deveDefinirStatusAtivoAoCadastrar() {
        when(repository.existeNomeAtivo(any())).thenReturn(false);
        when(repository.salvar(any())).thenAnswer(inv -> inv.getArgument(0));

        ArquiteturaReferencia resultado = useCase.executar(arquitetura);

        assertThat(resultado.getStatus()).isEqualTo(StatusArquitetura.ATIVA);
        assertThat(resultado.getDataCriacao()).isNotNull();
        assertThat(resultado.getDataAtualizacao()).isNotNull();
    }
}
