package br.gov.empresa.arquitetura.application.usecase.classificacao;

import br.gov.empresa.arquitetura.domain.exception.RecursoNaoEncontradoException;
import br.gov.empresa.arquitetura.domain.exception.RegraDeNegocioException;
import br.gov.empresa.arquitetura.domain.model.ArquiteturaReferencia;
import br.gov.empresa.arquitetura.domain.model.ClassificacaoArquitetural;
import br.gov.empresa.arquitetura.domain.model.enums.NivelAderencia;
import br.gov.empresa.arquitetura.domain.repository.ArquiteturaReferenciaRepository;
import br.gov.empresa.arquitetura.domain.repository.ClassificacaoArquiteturalRepository;
import br.gov.empresa.arquitetura.domain.repository.SistemaCorporativoRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.time.LocalDateTime;

@ApplicationScoped
public class ClassificarSistemaUseCase {

    @Inject
    ArquiteturaReferenciaRepository arquiteturaRepository;

    @Inject
    SistemaCorporativoRepository sistemaRepository;

    @Inject
    ClassificacaoArquiteturalRepository classificacaoRepository;

    public ClassificacaoArquitetural executar(ClassificacaoArquitetural classificacao) {
        sistemaRepository.buscarPorId(classificacao.getSistemaId())
                .orElseThrow(() -> new RecursoNaoEncontradoException(
                        "Sistema corporativo não encontrado com id: " + classificacao.getSistemaId()));

        ArquiteturaReferencia arquitetura = arquiteturaRepository.buscarPorId(classificacao.getArquiteturaId())
                .orElseThrow(() -> new RecursoNaoEncontradoException(
                        "Arquitetura de referência não encontrada com id: " + classificacao.getArquiteturaId()));

        if (!arquitetura.isAtiva()) {
            throw new RegraDeNegocioException(
                    "Não é possível classificar um sistema em uma arquitetura de referência inativa.");
        }

        validarJustificativa(classificacao.getNivelAderencia(), classificacao.getJustificativa());

        classificacao.setDataAvaliacao(LocalDateTime.now());
        return classificacaoRepository.salvar(classificacao);
    }

    private void validarJustificativa(NivelAderencia nivel, String justificativa) {
        if ((NivelAderencia.PARCIALMENTE_ADERENTE.equals(nivel) || NivelAderencia.NAO_ADERENTE.equals(nivel))
                && (justificativa == null || justificativa.isBlank())) {
            throw new RegraDeNegocioException(
                    "Justificativa é obrigatória para níveis PARCIALMENTE_ADERENTE e NAO_ADERENTE.");
        }
    }
}
