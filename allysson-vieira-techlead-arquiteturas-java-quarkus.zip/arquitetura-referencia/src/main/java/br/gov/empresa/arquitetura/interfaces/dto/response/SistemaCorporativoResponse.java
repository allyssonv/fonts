package br.gov.empresa.arquitetura.interfaces.dto.response;

import br.gov.empresa.arquitetura.domain.model.SistemaCorporativo;
import br.gov.empresa.arquitetura.domain.model.enums.Criticidade;
import br.gov.empresa.arquitetura.domain.model.enums.StatusSistema;

import java.time.LocalDateTime;
import java.util.UUID;

public record SistemaCorporativoResponse(
        UUID id,
        String nome,
        String sigla,
        String areaResponsavel,
        Criticidade criticidade,
        StatusSistema status,
        String arquiteturaAtual,
        LocalDateTime dataCriacao,
        LocalDateTime dataAtualizacao
) {
    public static SistemaCorporativoResponse from(SistemaCorporativo s) {
        return new SistemaCorporativoResponse(s.getId(), s.getNome(), s.getSigla(),
                s.getAreaResponsavel(), s.getCriticidade(), s.getStatus(), s.getArquiteturaAtual(),
                s.getDataCriacao(), s.getDataAtualizacao());
    }
}
