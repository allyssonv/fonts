package br.gov.empresa.arquitetura.infrastructure.persistence.mapper;

import br.gov.empresa.arquitetura.domain.model.SistemaCorporativo;
import br.gov.empresa.arquitetura.infrastructure.persistence.entity.SistemaCorporativoEntity;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class SistemaCorporativoMapper {

    public SistemaCorporativo toDomain(SistemaCorporativoEntity entity) {
        if (entity == null) return null;
        SistemaCorporativo domain = new SistemaCorporativo();
        domain.setId(entity.getId());
        domain.setNome(entity.getNome());
        domain.setSigla(entity.getSigla());
        domain.setAreaResponsavel(entity.getAreaResponsavel());
        domain.setCriticidade(entity.getCriticidade());
        domain.setStatus(entity.getStatus());
        domain.setArquiteturaAtual(entity.getArquiteturaAtual());
        domain.setDataCriacao(entity.getDataCriacao());
        domain.setDataAtualizacao(entity.getDataAtualizacao());
        return domain;
    }

    public SistemaCorporativoEntity toEntity(SistemaCorporativo domain) {
        if (domain == null) return null;
        SistemaCorporativoEntity entity = new SistemaCorporativoEntity();
        entity.setId(domain.getId());
        entity.setNome(domain.getNome());
        entity.setSigla(domain.getSigla());
        entity.setAreaResponsavel(domain.getAreaResponsavel());
        entity.setCriticidade(domain.getCriticidade());
        entity.setStatus(domain.getStatus());
        entity.setArquiteturaAtual(domain.getArquiteturaAtual());
        entity.setDataCriacao(domain.getDataCriacao());
        entity.setDataAtualizacao(domain.getDataAtualizacao());
        return entity;
    }
}
