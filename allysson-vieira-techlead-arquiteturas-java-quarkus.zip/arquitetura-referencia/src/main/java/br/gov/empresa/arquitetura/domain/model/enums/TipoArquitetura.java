package br.gov.empresa.arquitetura.domain.model.enums;

public enum TipoArquitetura {
    MICROSSERVICOS,
    MONOLITICA,
    ORIENTADA_A_EVENTOS,
    SERVERLESS,
    SOA,
    HIBRIDA
}
