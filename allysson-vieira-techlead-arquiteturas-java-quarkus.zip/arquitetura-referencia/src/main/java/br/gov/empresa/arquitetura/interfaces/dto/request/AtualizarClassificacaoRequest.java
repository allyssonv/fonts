package br.gov.empresa.arquitetura.interfaces.dto.request;

import br.gov.empresa.arquitetura.domain.model.enums.NivelAderencia;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record AtualizarClassificacaoRequest(
        @NotNull(message = "Nível de aderência é obrigatório")
        NivelAderencia nivelAderencia,

        String justificativa,

        @NotBlank(message = "Responsável pela avaliação é obrigatório")
        String responsavelAvaliacao
) {}
