package br.gov.empresa.arquitetura.domain.model;

import br.gov.empresa.arquitetura.domain.model.enums.SituacaoUso;

import java.util.UUID;

public class Tecnologia {

    private UUID id;
    private String nome;
    private String categoria;
    private String versaoRecomendada;
    private SituacaoUso situacaoUso;
    private String observacoes;

    public Tecnologia() {}

    public Tecnologia(UUID id, String nome, String categoria, String versaoRecomendada,
                      SituacaoUso situacaoUso, String observacoes) {
        this.id = id;
        this.nome = nome;
        this.categoria = categoria;
        this.versaoRecomendada = versaoRecomendada;
        this.situacaoUso = situacaoUso;
        this.observacoes = observacoes;
    }

    public UUID getId() { return id; }
    public String getNome() { return nome; }
    public String getCategoria() { return categoria; }
    public String getVersaoRecomendada() { return versaoRecomendada; }
    public SituacaoUso getSituacaoUso() { return situacaoUso; }
    public String getObservacoes() { return observacoes; }
    public void setId(UUID id) { this.id = id; }
    public void setNome(String nome) { this.nome = nome; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public void setVersaoRecomendada(String versaoRecomendada) { this.versaoRecomendada = versaoRecomendada; }
    public void setSituacaoUso(SituacaoUso situacaoUso) { this.situacaoUso = situacaoUso; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }
}
