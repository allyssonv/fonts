package br.gov.empresa.arquitetura.interfaces.rest;

import br.gov.empresa.arquitetura.application.usecase.classificacao.AtualizarClassificacaoUseCase;
import br.gov.empresa.arquitetura.application.usecase.classificacao.ClassificarSistemaUseCase;
import br.gov.empresa.arquitetura.domain.model.ClassificacaoArquitetural;
import br.gov.empresa.arquitetura.interfaces.dto.request.AtualizarClassificacaoRequest;
import br.gov.empresa.arquitetura.interfaces.dto.request.ClassificarSistemaRequest;
import br.gov.empresa.arquitetura.interfaces.dto.response.ClassificacaoArquiteturalResponse;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import java.net.URI;
import java.util.UUID;

@Path("/api/v1/classificacoes")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Tag(name = "Classificações Arquiteturais", description = "Classificação de sistemas em arquiteturas de referência")
public class ClassificacaoArquiteturalResource {

    @Inject ClassificarSistemaUseCase classificarUseCase;
    @Inject AtualizarClassificacaoUseCase atualizarUseCase;

    @POST
    @Operation(summary = "Classificar sistema em uma arquitetura de referência")
    public Response classificar(@Valid ClassificarSistemaRequest request) {
        ClassificacaoArquitetural classificacao = toClassificacao(request);
        ClassificacaoArquitetural criada = classificarUseCase.executar(classificacao);
        return Response.created(URI.create("/api/v1/classificacoes/" + criada.getId()))
                .entity(ClassificacaoArquiteturalResponse.from(criada))
                .build();
    }

    @PUT
    @Path("/{id}")
    @Operation(summary = "Atualizar classificação arquitetural")
    public ClassificacaoArquiteturalResponse atualizar(@PathParam("id") UUID id,
                                                        @Valid AtualizarClassificacaoRequest request) {
        ClassificacaoArquitetural dados = new ClassificacaoArquitetural();
        dados.setNivelAderencia(request.nivelAderencia());
        dados.setJustificativa(request.justificativa());
        dados.setResponsavelAvaliacao(request.responsavelAvaliacao());
        return ClassificacaoArquiteturalResponse.from(atualizarUseCase.executar(id, dados));
    }

    private ClassificacaoArquitetural toClassificacao(ClassificarSistemaRequest request) {
        ClassificacaoArquitetural c = new ClassificacaoArquitetural();
        c.setSistemaId(request.sistemaId());
        c.setArquiteturaId(request.arquiteturaId());
        c.setNivelAderencia(request.nivelAderencia());
        c.setJustificativa(request.justificativa());
        c.setResponsavelAvaliacao(request.responsavelAvaliacao());
        return c;
    }
}
