package br.gov.empresa.arquitetura.infrastructure.persistence.repository;

import br.gov.empresa.arquitetura.domain.model.SistemaCorporativo;
import br.gov.empresa.arquitetura.domain.repository.ClassificacaoArquiteturalRepository;
import br.gov.empresa.arquitetura.domain.repository.SistemaCorporativoRepository;
import br.gov.empresa.arquitetura.infrastructure.persistence.entity.SistemaCorporativoEntity;
import br.gov.empresa.arquitetura.infrastructure.persistence.mapper.SistemaCorporativoMapper;
import io.quarkus.hibernate.orm.panache.PanacheRepositoryBase;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

@ApplicationScoped
public class SistemaCorporativoRepositoryImpl
        implements SistemaCorporativoRepository, PanacheRepositoryBase<SistemaCorporativoEntity, UUID> {

    @Inject
    SistemaCorporativoMapper mapper;

    @Inject
    ClassificacaoArquiteturalRepository classificacaoRepository;

    @Override
    @Transactional
    public SistemaCorporativo salvar(SistemaCorporativo sistema) {
        SistemaCorporativoEntity entity = mapper.toEntity(sistema);
        if (entity.getId() == null) {
            persist(entity);
        } else {
            entity = getEntityManager().merge(entity);
        }
        return mapper.toDomain(entity);
    }

    @Override
    public Optional<SistemaCorporativo> buscarPorId(UUID id) {
        return findByIdOptional(id).map(mapper::toDomain);
    }

    @Override
    public List<SistemaCorporativo> listarTodos() {
        return listAll().stream().map(mapper::toDomain).toList();
    }

    @Override
    public boolean existeSigla(String sigla) {
        return count("sigla", sigla) > 0;
    }

    @Override
    public List<SistemaCorporativo> listarSemClassificacao() {
        Set<UUID> classificados = Set.copyOf(classificacaoRepository.listarSistemaIdsClassificados());
        return listAll().stream()
                .filter(e -> !classificados.contains(e.getId()))
                .map(mapper::toDomain)
                .toList();
    }
}
