package br.gov.empresa.arquitetura.interfaces.dto.response;

import br.gov.empresa.arquitetura.domain.model.Tecnologia;
import br.gov.empresa.arquitetura.domain.model.enums.SituacaoUso;

import java.util.UUID;

public record TecnologiaResponse(
        UUID id,
        String nome,
        String categoria,
        String versaoRecomendada,
        SituacaoUso situacaoUso,
        String observacoes
) {
    public static TecnologiaResponse from(Tecnologia t) {
        return new TecnologiaResponse(t.getId(), t.getNome(), t.getCategoria(),
                t.getVersaoRecomendada(), t.getSituacaoUso(), t.getObservacoes());
    }
}
