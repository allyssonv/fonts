package br.gov.empresa.arquitetura.application.usecase.sistema;

import br.gov.empresa.arquitetura.domain.exception.ConflitoUnicidadeException;
import br.gov.empresa.arquitetura.domain.model.SistemaCorporativo;
import br.gov.empresa.arquitetura.domain.model.enums.StatusSistema;
import br.gov.empresa.arquitetura.domain.repository.SistemaCorporativoRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.time.LocalDateTime;

@ApplicationScoped
public class CadastrarSistemaUseCase {

    @Inject
    SistemaCorporativoRepository repository;

    public SistemaCorporativo executar(SistemaCorporativo sistema) {
        if (repository.existeSigla(sistema.getSigla())) {
            throw new ConflitoUnicidadeException(
                    "Já existe um sistema corporativo com a sigla: " + sistema.getSigla());
        }

        sistema.setStatus(StatusSistema.ATIVO);
        sistema.setDataCriacao(LocalDateTime.now());
        sistema.setDataAtualizacao(LocalDateTime.now());

        return repository.salvar(sistema);
    }
}
