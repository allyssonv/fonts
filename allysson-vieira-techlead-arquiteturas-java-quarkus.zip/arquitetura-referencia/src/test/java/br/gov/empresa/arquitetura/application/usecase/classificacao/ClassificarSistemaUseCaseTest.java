package br.gov.empresa.arquitetura.application.usecase.classificacao;

import br.gov.empresa.arquitetura.domain.exception.RecursoNaoEncontradoException;
import br.gov.empresa.arquitetura.domain.exception.RegraDeNegocioException;
import br.gov.empresa.arquitetura.domain.model.ArquiteturaReferencia;
import br.gov.empresa.arquitetura.domain.model.ClassificacaoArquitetural;
import br.gov.empresa.arquitetura.domain.model.SistemaCorporativo;
import br.gov.empresa.arquitetura.domain.model.enums.NivelAderencia;
import br.gov.empresa.arquitetura.domain.model.enums.StatusArquitetura;
import br.gov.empresa.arquitetura.domain.repository.ArquiteturaReferenciaRepository;
import br.gov.empresa.arquitetura.domain.repository.ClassificacaoArquiteturalRepository;
import br.gov.empresa.arquitetura.domain.repository.SistemaCorporativoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ClassificarSistemaUseCaseTest {

    @Mock ArquiteturaReferenciaRepository arquiteturaRepository;
    @Mock SistemaCorporativoRepository sistemaRepository;
    @Mock ClassificacaoArquiteturalRepository classificacaoRepository;

    @InjectMocks
    ClassificarSistemaUseCase useCase;

    UUID sistemaId;
    UUID arquiteturaId;
    ArquiteturaReferencia arquiteturaAtiva;
    SistemaCorporativo sistema;
    ClassificacaoArquitetural classificacao;

    @BeforeEach
    void setUp() {
        sistemaId = UUID.randomUUID();
        arquiteturaId = UUID.randomUUID();

        sistema = new SistemaCorporativo();
        sistema.setId(sistemaId);

        arquiteturaAtiva = new ArquiteturaReferencia();
        arquiteturaAtiva.setId(arquiteturaId);
        arquiteturaAtiva.setStatus(StatusArquitetura.ATIVA);

        classificacao = new ClassificacaoArquitetural();
        classificacao.setSistemaId(sistemaId);
        classificacao.setArquiteturaId(arquiteturaId);
        classificacao.setNivelAderencia(NivelAderencia.ADERENTE);
        classificacao.setResponsavelAvaliacao("João Silva");
    }

    @Test
    void deveClassificarSistemaComSucesso() {
        when(sistemaRepository.buscarPorId(sistemaId)).thenReturn(Optional.of(sistema));
        when(arquiteturaRepository.buscarPorId(arquiteturaId)).thenReturn(Optional.of(arquiteturaAtiva));
        when(classificacaoRepository.salvar(any())).thenAnswer(inv -> {
            ClassificacaoArquitetural c = inv.getArgument(0);
            c.setId(UUID.randomUUID());
            return c;
        });

        ClassificacaoArquitetural resultado = useCase.executar(classificacao);

        assertThat(resultado.getDataAvaliacao()).isNotNull();
        verify(classificacaoRepository).salvar(any());
    }

    @Test
    void deveLancarExcecaoQuandoSistemaNaoEncontrado() {
        when(sistemaRepository.buscarPorId(sistemaId)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> useCase.executar(classificacao))
                .isInstanceOf(RecursoNaoEncontradoException.class)
                .hasMessageContaining(sistemaId.toString());
    }

    @Test
    void deveLancarExcecaoQuandoArquiteturaNaoEncontrada() {
        when(sistemaRepository.buscarPorId(sistemaId)).thenReturn(Optional.of(sistema));
        when(arquiteturaRepository.buscarPorId(arquiteturaId)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> useCase.executar(classificacao))
                .isInstanceOf(RecursoNaoEncontradoException.class)
                .hasMessageContaining(arquiteturaId.toString());
    }

    @Test
    void deveLancarExcecaoQuandoArquiteturaInativa() {
        arquiteturaAtiva.setStatus(StatusArquitetura.INATIVA);
        when(sistemaRepository.buscarPorId(sistemaId)).thenReturn(Optional.of(sistema));
        when(arquiteturaRepository.buscarPorId(arquiteturaId)).thenReturn(Optional.of(arquiteturaAtiva));

        assertThatThrownBy(() -> useCase.executar(classificacao))
                .isInstanceOf(RegraDeNegocioException.class)
                .hasMessageContaining("inativa");
    }

    @Test
    void deveLancarExcecaoJustificativaObrigatoriaParaParcialmenteAderente() {
        classificacao.setNivelAderencia(NivelAderencia.PARCIALMENTE_ADERENTE);
        classificacao.setJustificativa(null);
        when(sistemaRepository.buscarPorId(sistemaId)).thenReturn(Optional.of(sistema));
        when(arquiteturaRepository.buscarPorId(arquiteturaId)).thenReturn(Optional.of(arquiteturaAtiva));

        assertThatThrownBy(() -> useCase.executar(classificacao))
                .isInstanceOf(RegraDeNegocioException.class)
                .hasMessageContaining("Justificativa");
    }

    @Test
    void deveLancarExcecaoJustificativaObrigatoriaParaNaoAderente() {
        classificacao.setNivelAderencia(NivelAderencia.NAO_ADERENTE);
        classificacao.setJustificativa("  ");
        when(sistemaRepository.buscarPorId(sistemaId)).thenReturn(Optional.of(sistema));
        when(arquiteturaRepository.buscarPorId(arquiteturaId)).thenReturn(Optional.of(arquiteturaAtiva));

        assertThatThrownBy(() -> useCase.executar(classificacao))
                .isInstanceOf(RegraDeNegocioException.class)
                .hasMessageContaining("Justificativa");
    }

    @Test
    void devePermitirNaoAvaliadoSemJustificativa() {
        classificacao.setNivelAderencia(NivelAderencia.NAO_AVALIADO);
        classificacao.setJustificativa(null);
        when(sistemaRepository.buscarPorId(sistemaId)).thenReturn(Optional.of(sistema));
        when(arquiteturaRepository.buscarPorId(arquiteturaId)).thenReturn(Optional.of(arquiteturaAtiva));
        when(classificacaoRepository.salvar(any())).thenAnswer(inv -> inv.getArgument(0));

        ClassificacaoArquitetural resultado = useCase.executar(classificacao);

        assertThat(resultado).isNotNull();
    }
}
