package br.gov.empresa.arquitetura.domain.exception;

public class ConflitoUnicidadeException extends RuntimeException {

    public ConflitoUnicidadeException(String mensagem) {
        super(mensagem);
    }
}
