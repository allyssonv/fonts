package br.gov.empresa.arquitetura.application.usecase.classificacao;

import br.gov.empresa.arquitetura.domain.exception.RecursoNaoEncontradoException;
import br.gov.empresa.arquitetura.domain.model.ClassificacaoArquitetural;
import br.gov.empresa.arquitetura.domain.repository.ArquiteturaReferenciaRepository;
import br.gov.empresa.arquitetura.domain.repository.ClassificacaoArquiteturalRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.List;
import java.util.UUID;

@ApplicationScoped
public class ConsultarSistemasPorArquiteturaUseCase {

    @Inject
    ArquiteturaReferenciaRepository arquiteturaRepository;

    @Inject
    ClassificacaoArquiteturalRepository classificacaoRepository;

    public List<ClassificacaoArquitetural> executar(UUID arquiteturaId) {
        arquiteturaRepository.buscarPorId(arquiteturaId)
                .orElseThrow(() -> new RecursoNaoEncontradoException(
                        "Arquitetura de referência não encontrada com id: " + arquiteturaId));

        return classificacaoRepository.listarPorArquiteturaId(arquiteturaId);
    }
}
