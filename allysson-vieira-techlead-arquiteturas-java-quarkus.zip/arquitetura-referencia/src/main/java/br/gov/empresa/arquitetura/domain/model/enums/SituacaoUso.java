package br.gov.empresa.arquitetura.domain.model.enums;

public enum SituacaoUso {
    RECOMENDADA,
    PERMITIDA,
    RESTRITA,
    DEPRECIADA
}
