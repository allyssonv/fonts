package br.gov.empresa.arquitetura.interfaces.dto.request;

import br.gov.empresa.arquitetura.domain.model.enums.Criticidade;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record CadastrarSistemaRequest(
        @NotBlank(message = "Nome é obrigatório")
        String nome,

        @NotBlank(message = "Sigla é obrigatória")
        String sigla,

        @NotBlank(message = "Área responsável é obrigatória")
        String areaResponsavel,

        @NotNull(message = "Criticidade é obrigatória")
        Criticidade criticidade,

        String arquiteturaAtual
) {}
