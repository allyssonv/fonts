package br.gov.empresa.arquitetura.application.usecase.sistema;

import br.gov.empresa.arquitetura.domain.exception.ConflitoUnicidadeException;
import br.gov.empresa.arquitetura.domain.model.SistemaCorporativo;
import br.gov.empresa.arquitetura.domain.model.enums.Criticidade;
import br.gov.empresa.arquitetura.domain.model.enums.StatusSistema;
import br.gov.empresa.arquitetura.domain.repository.SistemaCorporativoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CadastrarSistemaUseCaseTest {

    @Mock
    SistemaCorporativoRepository repository;

    @InjectMocks
    CadastrarSistemaUseCase useCase;

    SistemaCorporativo sistema;

    @BeforeEach
    void setUp() {
        sistema = new SistemaCorporativo();
        sistema.setNome("Sistema de Pagamentos");
        sistema.setSigla("SIPAG");
        sistema.setAreaResponsavel("Financeiro");
        sistema.setCriticidade(Criticidade.CRITICA);
    }

    @Test
    void deveCadastrarSistemaComSucesso() {
        when(repository.existeSigla("SIPAG")).thenReturn(false);
        SistemaCorporativo salvo = new SistemaCorporativo();
        salvo.setId(UUID.randomUUID());
        salvo.setSigla("SIPAG");
        salvo.setStatus(StatusSistema.ATIVO);
        when(repository.salvar(any())).thenReturn(salvo);

        SistemaCorporativo resultado = useCase.executar(sistema);

        assertThat(resultado.getId()).isNotNull();
        assertThat(resultado.getStatus()).isEqualTo(StatusSistema.ATIVO);
    }

    @Test
    void deveLancarExcecaoQuandoSiglaJaExiste() {
        when(repository.existeSigla("SIPAG")).thenReturn(true);

        assertThatThrownBy(() -> useCase.executar(sistema))
                .isInstanceOf(ConflitoUnicidadeException.class)
                .hasMessageContaining("SIPAG");

        verify(repository, never()).salvar(any());
    }

    @Test
    void deveDefinirStatusAtivoAoCadastrar() {
        when(repository.existeSigla(any())).thenReturn(false);
        when(repository.salvar(any())).thenAnswer(inv -> inv.getArgument(0));

        SistemaCorporativo resultado = useCase.executar(sistema);

        assertThat(resultado.getStatus()).isEqualTo(StatusSistema.ATIVO);
        assertThat(resultado.getDataCriacao()).isNotNull();
    }
}
