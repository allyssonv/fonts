package br.gov.empresa.arquitetura.application.usecase.arquitetura;

import br.gov.empresa.arquitetura.domain.exception.RecursoNaoEncontradoException;
import br.gov.empresa.arquitetura.domain.model.ArquiteturaReferencia;
import br.gov.empresa.arquitetura.domain.repository.ArquiteturaReferenciaRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ConsultarArquiteturaUseCaseTest {

    @Mock
    ArquiteturaReferenciaRepository repository;

    @InjectMocks
    ConsultarArquiteturaUseCase useCase;

    @Test
    void deveRetornarArquiteturaQuandoEncontrada() {
        UUID id = UUID.randomUUID();
        ArquiteturaReferencia arquitetura = new ArquiteturaReferencia();
        arquitetura.setId(id);
        arquitetura.setNome("SOA Enterprise");
        when(repository.buscarPorId(id)).thenReturn(Optional.of(arquitetura));

        ArquiteturaReferencia resultado = useCase.executar(id);

        assertThat(resultado.getId()).isEqualTo(id);
        assertThat(resultado.getNome()).isEqualTo("SOA Enterprise");
    }

    @Test
    void deveLancarExcecaoQuandoNaoEncontrada() {
        UUID id = UUID.randomUUID();
        when(repository.buscarPorId(id)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> useCase.executar(id))
                .isInstanceOf(RecursoNaoEncontradoException.class)
                .hasMessageContaining(id.toString());
    }
}
