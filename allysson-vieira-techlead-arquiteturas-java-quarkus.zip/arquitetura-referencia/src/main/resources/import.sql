-- =============================================================
-- Dados iniciais — carregados automaticamente pelo Hibernate
-- =============================================================

-- Arquiteturas de Referência
INSERT INTO arquitetura_referencia (id, nome, descricao, tipo, status, datacriacao, dataatualizacao) VALUES
  ('a1000000-0000-0000-0000-000000000001', 'Microsserviços Cloud Native', 'Arquitetura baseada em containers, orquestração Kubernetes e princípios 12-factor app.', 'MICROSSERVICOS', 'ATIVA', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('a1000000-0000-0000-0000-000000000002', 'Monolito Modular', 'Aplicação única com módulos bem definidos e baixo acoplamento interno.', 'MONOLITICA', 'ATIVA', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('a1000000-0000-0000-0000-000000000003', 'Orientada a Eventos', 'Comunicação assíncrona via mensageria; alta resiliência e desacoplamento entre produtores e consumidores.', 'ORIENTADA_A_EVENTOS', 'ATIVA', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('a1000000-0000-0000-0000-000000000004', 'SOA Legado', 'Arquitetura orientada a serviços baseada em ESB. Candidata a modernização.', 'SOA', 'INATIVA', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- Tecnologias recomendadas por arquitetura
INSERT INTO tecnologia (id, nome, categoria, versaorecomendada, situacaouso, observacoes, arquitetura_id) VALUES
  ('b1000000-0000-0000-0000-000000000001', 'Quarkus',      'Framework',    '3.x',   'RECOMENDADA', 'Framework nativo cloud para Java.',           'a1000000-0000-0000-0000-000000000001'),
  ('b1000000-0000-0000-0000-000000000002', 'Kubernetes',   'Orquestração', '1.30+', 'RECOMENDADA', 'Orquestrador padrão de containers.',          'a1000000-0000-0000-0000-000000000001'),
  ('b1000000-0000-0000-0000-000000000003', 'Docker',       'Container',    '26+',   'RECOMENDADA', 'Runtime de containers.',                      'a1000000-0000-0000-0000-000000000001'),
  ('b1000000-0000-0000-0000-000000000004', 'Spring Boot',  'Framework',    '3.x',   'PERMITIDA',   'Alternativa ao Quarkus para monolito modular.','a1000000-0000-0000-0000-000000000002'),
  ('b1000000-0000-0000-0000-000000000005', 'Apache Kafka', 'Mensageria',   '3.x',   'RECOMENDADA', 'Broker padrão para arquitetura orientada a eventos.', 'a1000000-0000-0000-0000-000000000003'),
  ('b1000000-0000-0000-0000-000000000006', 'IBM MQ',       'Mensageria',   '9.x',   'DEPRECIADA',  'Substituir por Kafka nas novas iniciativas.',  'a1000000-0000-0000-0000-000000000004');

-- Sistemas Corporativos
INSERT INTO sistema_corporativo (id, nome, sigla, arearesponsavel, criticidade, status, arquiteturaatual, datacriacao, dataatualizacao) VALUES
  ('c1000000-0000-0000-0000-000000000001', 'Sistema de Pagamentos',         'SIPAG',  'Financeiro',          'CRITICA',  'ATIVO',             'Microsserviços Cloud Native', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('c1000000-0000-0000-0000-000000000002', 'Portal do Colaborador',         'PORCOL', 'Recursos Humanos',    'MEDIA',    'ATIVO',             'Monolito Modular',            CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('c1000000-0000-0000-0000-000000000003', 'Sistema de Gestão Financeira',  'SIGFIN', 'Financeiro',          'ALTA',     'ATIVO',             'SOA Legado',                  CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('c1000000-0000-0000-0000-000000000004', 'Plataforma de Notificações',    'PLANOT', 'Tecnologia',          'ALTA',     'ATIVO',             'Orientada a Eventos',         CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('c1000000-0000-0000-0000-000000000005', 'Sistema de Relatórios Legado',  'SIRLEG', 'Controladoria',       'BAIXA',    'EM_DESCONTINUACAO', 'SOA Legado',                  CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('c1000000-0000-0000-0000-000000000006', 'API de Autenticação',           'APIAUT', 'Segurança',           'CRITICA',  'ATIVO',             NULL,                          CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- Classificações Arquiteturais
INSERT INTO classificacao_arquitetural (id, sistema_id, arquitetura_id, niveladerencia, justificativa, responsavelavaliacao, dataavaliacao) VALUES
  ('d1000000-0000-0000-0000-000000000001', 'c1000000-0000-0000-0000-000000000001', 'a1000000-0000-0000-0000-000000000001', 'ADERENTE',              NULL,                                                                   'Tech Lead - Financeiro', CURRENT_TIMESTAMP),
  ('d1000000-0000-0000-0000-000000000002', 'c1000000-0000-0000-0000-000000000002', 'a1000000-0000-0000-0000-000000000002', 'PARCIALMENTE_ADERENTE', 'Módulos ainda com acoplamento direto via chamada de método interno.',    'Tech Lead - RH',         CURRENT_TIMESTAMP),
  ('d1000000-0000-0000-0000-000000000003', 'c1000000-0000-0000-0000-000000000003', 'a1000000-0000-0000-0000-000000000003', 'NAO_ADERENTE',          'Sistema usa comunicação síncrona REST; não utiliza broker de eventos.', 'Arquiteto Corporativo',  CURRENT_TIMESTAMP),
  ('d1000000-0000-0000-0000-000000000004', 'c1000000-0000-0000-0000-000000000004', 'a1000000-0000-0000-0000-000000000003', 'ADERENTE',              NULL,                                                                   'Tech Lead - Tecnologia', CURRENT_TIMESTAMP),
  ('d1000000-0000-0000-0000-000000000005', 'c1000000-0000-0000-0000-000000000005', 'a1000000-0000-0000-0000-000000000002', 'NAO_ADERENTE',          'Sistema em descontinuação; não atende nenhum requisito da arquitetura alvo.', 'Arquiteto Corporativo', CURRENT_TIMESTAMP);
-- c1000000-0000-0000-0000-000000000006 (APIAUT) intencionalmente sem classificação para demonstrar /sem-classificacao
