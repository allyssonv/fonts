package br.gov.empresa.arquitetura.interfaces.rest;

import io.quarkus.test.junit.QuarkusTest;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

@QuarkusTest
class ArquiteturaReferenciaResourceTest {

    @Test
    void deveCadastrarArquiteturaComSucesso() {
        given()
                .contentType(ContentType.JSON)
                .body("""
                        {
                            "nome": "Microsservicos Cloud Native",
                            "descricao": "Arquitetura baseada em containers e Kubernetes",
                            "tipo": "MICROSSERVICOS",
                            "tecnologiasRecomendadas": [
                                {"nome": "Quarkus", "categoria": "Framework", "versaoRecomendada": "3.x",
                                 "situacaoUso": "RECOMENDADA", "observacoes": "Framework nativo cloud"}
                            ]
                        }
                        """)
                .when().post("/api/v1/arquiteturas")
                .then()
                .statusCode(201)
                .body("id", notNullValue())
                .body("nome", equalTo("Microsservicos Cloud Native"))
                .body("status", equalTo("ATIVA"));
    }

    @Test
    void deveRetornar409QuandoNomeDuplicado() {
        String body = """
                {
                    "nome": "Arquitetura Unica",
                    "descricao": "Descrição",
                    "tipo": "MONOLITICA"
                }
                """;
        given().contentType(ContentType.JSON).body(body)
                .when().post("/api/v1/arquiteturas").then().statusCode(201);

        given().contentType(ContentType.JSON).body(body)
                .when().post("/api/v1/arquiteturas").then().statusCode(409);
    }

    @Test
    void deveListarArquiteturas() {
        given()
                .when().get("/api/v1/arquiteturas")
                .then()
                .statusCode(200)
                .body("$", instanceOf(java.util.List.class));
    }

    @Test
    void deveRetornar404ParaIdInexistente() {
        given()
                .when().get("/api/v1/arquiteturas/00000000-0000-0000-0000-000000000001")
                .then()
                .statusCode(404);
    }

    @Test
    void deveInativarArquitetura() {
        String id = given()
                .contentType(ContentType.JSON)
                .body("""
                        {"nome": "Arq para Inativar", "descricao": "Teste", "tipo": "SOA"}
                        """)
                .when().post("/api/v1/arquiteturas")
                .then().statusCode(201)
                .extract().path("id");

        given()
                .when().patch("/api/v1/arquiteturas/" + id + "/inativar")
                .then()
                .statusCode(200)
                .body("status", equalTo("INATIVA"));
    }

    @Test
    void deveRetornar400QuandoNomeFaltando() {
        given()
                .contentType(ContentType.JSON)
                .body("""
                        {"descricao": "Sem nome", "tipo": "MONOLITICA"}
                        """)
                .when().post("/api/v1/arquiteturas")
                .then()
                .statusCode(400);
    }
}
