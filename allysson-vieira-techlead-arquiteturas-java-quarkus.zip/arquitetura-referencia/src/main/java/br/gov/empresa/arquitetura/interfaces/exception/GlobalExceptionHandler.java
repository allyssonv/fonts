package br.gov.empresa.arquitetura.interfaces.exception;

import br.gov.empresa.arquitetura.domain.exception.ConflitoUnicidadeException;
import br.gov.empresa.arquitetura.domain.exception.RecursoNaoEncontradoException;
import br.gov.empresa.arquitetura.domain.exception.RegraDeNegocioException;
import jakarta.validation.ConstraintViolationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;

import java.util.stream.Collectors;

public class GlobalExceptionHandler {

    @Provider
    public static class RecursoNaoEncontradoMapper implements ExceptionMapper<RecursoNaoEncontradoException> {
        @Override
        public Response toResponse(RecursoNaoEncontradoException ex) {
            return Response.status(Response.Status.NOT_FOUND)
                    .entity(new ErroResponse(404, ex.getMessage()))
                    .build();
        }
    }

    @Provider
    public static class ConflitoUnicidadeMapper implements ExceptionMapper<ConflitoUnicidadeException> {
        @Override
        public Response toResponse(ConflitoUnicidadeException ex) {
            return Response.status(Response.Status.CONFLICT)
                    .entity(new ErroResponse(409, ex.getMessage()))
                    .build();
        }
    }

    @Provider
    public static class RegraDeNegocioMapper implements ExceptionMapper<RegraDeNegocioException> {
        @Override
        public Response toResponse(RegraDeNegocioException ex) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity(new ErroResponse(400, ex.getMessage()))
                    .build();
        }
    }

    @Provider
    public static class ConstraintViolationMapper implements ExceptionMapper<ConstraintViolationException> {
        @Override
        public Response toResponse(ConstraintViolationException ex) {
            String mensagem = ex.getConstraintViolations().stream()
                    .map(v -> v.getPropertyPath() + ": " + v.getMessage())
                    .collect(Collectors.joining("; "));
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity(new ErroResponse(400, mensagem))
                    .build();
        }
    }

    public record ErroResponse(int status, String mensagem) {}
}
