package br.gov.empresa.arquitetura.application.usecase.classificacao;

import br.gov.empresa.arquitetura.domain.exception.RecursoNaoEncontradoException;
import br.gov.empresa.arquitetura.domain.exception.RegraDeNegocioException;
import br.gov.empresa.arquitetura.domain.model.ClassificacaoArquitetural;
import br.gov.empresa.arquitetura.domain.model.enums.NivelAderencia;
import br.gov.empresa.arquitetura.domain.repository.ClassificacaoArquiteturalRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AtualizarClassificacaoUseCaseTest {

    @Mock
    ClassificacaoArquiteturalRepository repository;

    @InjectMocks
    AtualizarClassificacaoUseCase useCase;

    UUID id;
    ClassificacaoArquitetural existente;
    ClassificacaoArquitetural dados;

    @BeforeEach
    void setUp() {
        id = UUID.randomUUID();
        existente = new ClassificacaoArquitetural();
        existente.setId(id);
        existente.setNivelAderencia(NivelAderencia.ADERENTE);
        existente.setResponsavelAvaliacao("Maria");
        existente.setDataAvaliacao(LocalDateTime.now().minusDays(5));

        dados = new ClassificacaoArquitetural();
        dados.setNivelAderencia(NivelAderencia.PARCIALMENTE_ADERENTE);
        dados.setJustificativa("Falta implementar padrão X");
        dados.setResponsavelAvaliacao("João");
    }

    @Test
    void deveAtualizarClassificacaoComSucesso() {
        when(repository.buscarPorId(id)).thenReturn(Optional.of(existente));
        when(repository.salvar(any())).thenAnswer(inv -> inv.getArgument(0));

        ClassificacaoArquitetural resultado = useCase.executar(id, dados);

        assertThat(resultado.getNivelAderencia()).isEqualTo(NivelAderencia.PARCIALMENTE_ADERENTE);
        assertThat(resultado.getJustificativa()).isEqualTo("Falta implementar padrão X");
        assertThat(resultado.getResponsavelAvaliacao()).isEqualTo("João");
        assertThat(resultado.getDataAvaliacao()).isNotNull();
    }

    @Test
    void deveLancarExcecaoQuandoNaoEncontrada() {
        when(repository.buscarPorId(id)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> useCase.executar(id, dados))
                .isInstanceOf(RecursoNaoEncontradoException.class);
    }

    @Test
    void deveLancarExcecaoQuandoJustificativaAusenteParaNaoAderente() {
        dados.setNivelAderencia(NivelAderencia.NAO_ADERENTE);
        dados.setJustificativa(null);
        when(repository.buscarPorId(id)).thenReturn(Optional.of(existente));

        assertThatThrownBy(() -> useCase.executar(id, dados))
                .isInstanceOf(RegraDeNegocioException.class)
                .hasMessageContaining("Justificativa");
    }
}
