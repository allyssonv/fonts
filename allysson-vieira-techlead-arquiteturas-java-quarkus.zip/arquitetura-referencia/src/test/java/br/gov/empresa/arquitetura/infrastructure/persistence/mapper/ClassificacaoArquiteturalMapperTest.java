package br.gov.empresa.arquitetura.infrastructure.persistence.mapper;

import br.gov.empresa.arquitetura.domain.model.ClassificacaoArquitetural;
import br.gov.empresa.arquitetura.domain.model.enums.NivelAderencia;
import br.gov.empresa.arquitetura.infrastructure.persistence.entity.ClassificacaoArquiteturalEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

class ClassificacaoArquiteturalMapperTest {

    ClassificacaoArquiteturalMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new ClassificacaoArquiteturalMapper();
    }

    @Test
    void deveMappearEntityParaDomain() {
        ClassificacaoArquiteturalEntity entity = criarEntity();

        ClassificacaoArquitetural domain = mapper.toDomain(entity);

        assertThat(domain).isNotNull();
        assertThat(domain.getId()).isEqualTo(entity.getId());
        assertThat(domain.getSistemaId()).isEqualTo(entity.getSistemaId());
        assertThat(domain.getArquiteturaId()).isEqualTo(entity.getArquiteturaId());
        assertThat(domain.getNivelAderencia()).isEqualTo(NivelAderencia.ADERENTE);
        assertThat(domain.getJustificativa()).isEqualTo("Justif");
        assertThat(domain.getResponsavelAvaliacao()).isEqualTo("TL");
        assertThat(domain.getDataAvaliacao()).isNotNull();
    }

    @Test
    void deveMappearDomainParaEntity() {
        ClassificacaoArquitetural domain = criarDomain();

        ClassificacaoArquiteturalEntity entity = mapper.toEntity(domain);

        assertThat(entity).isNotNull();
        assertThat(entity.getId()).isEqualTo(domain.getId());
        assertThat(entity.getSistemaId()).isEqualTo(domain.getSistemaId());
        assertThat(entity.getArquiteturaId()).isEqualTo(domain.getArquiteturaId());
        assertThat(entity.getNivelAderencia()).isEqualTo(NivelAderencia.PARCIALMENTE_ADERENTE);
        assertThat(entity.getJustificativa()).isEqualTo("Falta algo");
        assertThat(entity.getResponsavelAvaliacao()).isEqualTo("Arquiteto");
    }

    @Test
    void deveRetornarNullParaEntityNula() {
        assertThat(mapper.toDomain(null)).isNull();
    }

    @Test
    void deveRetornarNullParaDomainNulo() {
        assertThat(mapper.toEntity(null)).isNull();
    }

    private ClassificacaoArquiteturalEntity criarEntity() {
        ClassificacaoArquiteturalEntity entity = new ClassificacaoArquiteturalEntity();
        entity.setId(UUID.randomUUID());
        entity.setSistemaId(UUID.randomUUID());
        entity.setArquiteturaId(UUID.randomUUID());
        entity.setNivelAderencia(NivelAderencia.ADERENTE);
        entity.setJustificativa("Justif");
        entity.setResponsavelAvaliacao("TL");
        entity.setDataAvaliacao(LocalDateTime.now());
        return entity;
    }

    private ClassificacaoArquitetural criarDomain() {
        ClassificacaoArquitetural domain = new ClassificacaoArquitetural();
        domain.setId(UUID.randomUUID());
        domain.setSistemaId(UUID.randomUUID());
        domain.setArquiteturaId(UUID.randomUUID());
        domain.setNivelAderencia(NivelAderencia.PARCIALMENTE_ADERENTE);
        domain.setJustificativa("Falta algo");
        domain.setResponsavelAvaliacao("Arquiteto");
        domain.setDataAvaliacao(LocalDateTime.now());
        return domain;
    }
}
