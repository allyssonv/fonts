package br.gov.empresa.arquitetura.application.usecase.arquitetura;

import br.gov.empresa.arquitetura.domain.model.ArquiteturaReferencia;
import br.gov.empresa.arquitetura.domain.repository.ArquiteturaReferenciaRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ListarArquiteturasUseCaseTest {

    @Mock
    ArquiteturaReferenciaRepository repository;

    @InjectMocks
    ListarArquiteturasUseCase useCase;

    @Test
    void deveRetornarListaDeArquiteturas() {
        ArquiteturaReferencia a1 = new ArquiteturaReferencia();
        a1.setNome("A1");
        ArquiteturaReferencia a2 = new ArquiteturaReferencia();
        a2.setNome("A2");
        when(repository.listarTodas()).thenReturn(List.of(a1, a2));

        List<ArquiteturaReferencia> resultado = useCase.executar();

        assertThat(resultado).hasSize(2);
    }

    @Test
    void deveRetornarListaVaziaQuandoNaoHaArquiteturas() {
        when(repository.listarTodas()).thenReturn(List.of());

        List<ArquiteturaReferencia> resultado = useCase.executar();

        assertThat(resultado).isEmpty();
    }
}
