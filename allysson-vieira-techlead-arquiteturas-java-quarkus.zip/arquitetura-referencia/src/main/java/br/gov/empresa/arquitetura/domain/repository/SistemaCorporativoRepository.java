package br.gov.empresa.arquitetura.domain.repository;

import br.gov.empresa.arquitetura.domain.model.SistemaCorporativo;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface SistemaCorporativoRepository {

    SistemaCorporativo salvar(SistemaCorporativo sistema);

    Optional<SistemaCorporativo> buscarPorId(UUID id);

    List<SistemaCorporativo> listarTodos();

    boolean existeSigla(String sigla);

    List<SistemaCorporativo> listarSemClassificacao();
}
