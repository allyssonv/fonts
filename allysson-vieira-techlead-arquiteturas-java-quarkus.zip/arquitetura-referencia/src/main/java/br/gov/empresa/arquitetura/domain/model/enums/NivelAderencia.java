package br.gov.empresa.arquitetura.domain.model.enums;

public enum NivelAderencia {
    ADERENTE,
    PARCIALMENTE_ADERENTE,
    NAO_ADERENTE,
    NAO_AVALIADO
}
