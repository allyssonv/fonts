package br.gov.empresa.arquitetura.interfaces.rest;

import io.quarkus.test.junit.QuarkusTest;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

@QuarkusTest
class ClassificacaoArquiteturalResourceTest {

    private String criarArquitetura(String nome) {
        return given()
                .contentType(ContentType.JSON)
                .body(String.format("""
                        {"nome": "%s", "descricao": "Desc", "tipo": "MICROSSERVICOS"}
                        """, nome))
                .when().post("/api/v1/arquiteturas")
                .then().statusCode(201)
                .extract().path("id");
    }

    private String criarSistema(String sigla) {
        return given()
                .contentType(ContentType.JSON)
                .body(String.format("""
                        {"nome": "Sistema %s", "sigla": "%s", "areaResponsavel": "TI", "criticidade": "ALTA"}
                        """, sigla, sigla))
                .when().post("/api/v1/sistemas")
                .then().statusCode(201)
                .extract().path("id");
    }

    @Test
    void deveClassificarSistemaComSucesso() {
        String arquiteturaId = criarArquitetura("Arq Classif Test");
        String sistemaId = criarSistema("CLST1");

        given()
                .contentType(ContentType.JSON)
                .body(String.format("""
                        {
                            "sistemaId": "%s",
                            "arquiteturaId": "%s",
                            "nivelAderencia": "ADERENTE",
                            "responsavelAvaliacao": "Tech Lead"
                        }
                        """, sistemaId, arquiteturaId))
                .when().post("/api/v1/classificacoes")
                .then()
                .statusCode(201)
                .body("id", notNullValue())
                .body("nivelAderencia", equalTo("ADERENTE"));
    }

    @Test
    void deveRetornar400QuandoJustificativaAusenteParaParcialmenteAderente() {
        String arquiteturaId = criarArquitetura("Arq Parcial Test");
        String sistemaId = criarSistema("PARC1");

        given()
                .contentType(ContentType.JSON)
                .body(String.format("""
                        {
                            "sistemaId": "%s",
                            "arquiteturaId": "%s",
                            "nivelAderencia": "PARCIALMENTE_ADERENTE",
                            "responsavelAvaliacao": "Tech Lead"
                        }
                        """, sistemaId, arquiteturaId))
                .when().post("/api/v1/classificacoes")
                .then()
                .statusCode(400);
    }

    @Test
    void deveRetornar400AoClassificarEmArquiteturaInativa() {
        String arquiteturaId = criarArquitetura("Arq Inativa Test");
        String sistemaId = criarSistema("INAT1");

        given().when().patch("/api/v1/arquiteturas/" + arquiteturaId + "/inativar")
                .then().statusCode(200);

        given()
                .contentType(ContentType.JSON)
                .body(String.format("""
                        {
                            "sistemaId": "%s",
                            "arquiteturaId": "%s",
                            "nivelAderencia": "ADERENTE",
                            "responsavelAvaliacao": "TL"
                        }
                        """, sistemaId, arquiteturaId))
                .when().post("/api/v1/classificacoes")
                .then()
                .statusCode(400);
    }

    @Test
    void deveAtualizarClassificacaoComSucesso() {
        String arquiteturaId = criarArquitetura("Arq Atualizar Test");
        String sistemaId = criarSistema("ATUA1");

        String classificacaoId = given()
                .contentType(ContentType.JSON)
                .body(String.format("""
                        {
                            "sistemaId": "%s",
                            "arquiteturaId": "%s",
                            "nivelAderencia": "ADERENTE",
                            "responsavelAvaliacao": "TL"
                        }
                        """, sistemaId, arquiteturaId))
                .when().post("/api/v1/classificacoes")
                .then().statusCode(201)
                .extract().path("id");

        given()
                .contentType(ContentType.JSON)
                .body("""
                        {
                            "nivelAderencia": "PARCIALMENTE_ADERENTE",
                            "justificativa": "Falta adotar padrão X na camada de domínio",
                            "responsavelAvaliacao": "Novo TL"
                        }
                        """)
                .when().put("/api/v1/classificacoes/" + classificacaoId)
                .then()
                .statusCode(200)
                .body("nivelAderencia", equalTo("PARCIALMENTE_ADERENTE"))
                .body("responsavelAvaliacao", equalTo("Novo TL"));
    }

    @Test
    void deveListarSistemasPorArquitetura() {
        String arquiteturaId = criarArquitetura("Arq Listar Sistemas");
        String sistemaId = criarSistema("LIST1");

        given()
                .contentType(ContentType.JSON)
                .body(String.format("""
                        {
                            "sistemaId": "%s",
                            "arquiteturaId": "%s",
                            "nivelAderencia": "ADERENTE",
                            "responsavelAvaliacao": "TL"
                        }
                        """, sistemaId, arquiteturaId))
                .when().post("/api/v1/classificacoes")
                .then().statusCode(201);

        given()
                .when().get("/api/v1/arquiteturas/" + arquiteturaId + "/sistemas")
                .then()
                .statusCode(200)
                .body("$", hasSize(greaterThan(0)));
    }
}
