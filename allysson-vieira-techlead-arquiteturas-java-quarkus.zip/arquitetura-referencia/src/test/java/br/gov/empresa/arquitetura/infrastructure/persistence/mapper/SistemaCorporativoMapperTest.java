package br.gov.empresa.arquitetura.infrastructure.persistence.mapper;

import br.gov.empresa.arquitetura.domain.model.SistemaCorporativo;
import br.gov.empresa.arquitetura.domain.model.enums.Criticidade;
import br.gov.empresa.arquitetura.domain.model.enums.StatusSistema;
import br.gov.empresa.arquitetura.infrastructure.persistence.entity.SistemaCorporativoEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

class SistemaCorporativoMapperTest {

    SistemaCorporativoMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new SistemaCorporativoMapper();
    }

    @Test
    void deveMappearEntityParaDomain() {
        SistemaCorporativoEntity entity = criarEntity();

        SistemaCorporativo domain = mapper.toDomain(entity);

        assertThat(domain).isNotNull();
        assertThat(domain.getId()).isEqualTo(entity.getId());
        assertThat(domain.getNome()).isEqualTo("ERP");
        assertThat(domain.getSigla()).isEqualTo("ERPSIG");
        assertThat(domain.getAreaResponsavel()).isEqualTo("TI");
        assertThat(domain.getCriticidade()).isEqualTo(Criticidade.CRITICA);
        assertThat(domain.getStatus()).isEqualTo(StatusSistema.ATIVO);
        assertThat(domain.getArquiteturaAtual()).isEqualTo("Legado");
        assertThat(domain.getDataCriacao()).isNotNull();
        assertThat(domain.getDataAtualizacao()).isNotNull();
    }

    @Test
    void deveMappearDomainParaEntity() {
        SistemaCorporativo domain = criarDomain();

        SistemaCorporativoEntity entity = mapper.toEntity(domain);

        assertThat(entity).isNotNull();
        assertThat(entity.getId()).isEqualTo(domain.getId());
        assertThat(entity.getNome()).isEqualTo("ERP");
        assertThat(entity.getSigla()).isEqualTo("ERPSIG");
        assertThat(entity.getCriticidade()).isEqualTo(Criticidade.CRITICA);
        assertThat(entity.getStatus()).isEqualTo(StatusSistema.ATIVO);
    }

    @Test
    void deveRetornarNullParaEntityNula() {
        assertThat(mapper.toDomain(null)).isNull();
    }

    @Test
    void deveRetornarNullParaDomainNulo() {
        assertThat(mapper.toEntity(null)).isNull();
    }

    private SistemaCorporativoEntity criarEntity() {
        SistemaCorporativoEntity entity = new SistemaCorporativoEntity();
        entity.setId(UUID.randomUUID());
        entity.setNome("ERP");
        entity.setSigla("ERPSIG");
        entity.setAreaResponsavel("TI");
        entity.setCriticidade(Criticidade.CRITICA);
        entity.setStatus(StatusSistema.ATIVO);
        entity.setArquiteturaAtual("Legado");
        entity.setDataCriacao(LocalDateTime.now());
        entity.setDataAtualizacao(LocalDateTime.now());
        return entity;
    }

    private SistemaCorporativo criarDomain() {
        SistemaCorporativo domain = new SistemaCorporativo();
        domain.setId(UUID.randomUUID());
        domain.setNome("ERP");
        domain.setSigla("ERPSIG");
        domain.setAreaResponsavel("TI");
        domain.setCriticidade(Criticidade.CRITICA);
        domain.setStatus(StatusSistema.ATIVO);
        domain.setArquiteturaAtual("Legado");
        domain.setDataCriacao(LocalDateTime.now());
        domain.setDataAtualizacao(LocalDateTime.now());
        return domain;
    }
}
