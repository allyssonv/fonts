package br.gov.empresa.arquitetura.domain.repository;

import br.gov.empresa.arquitetura.domain.model.ClassificacaoArquitetural;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface ClassificacaoArquiteturalRepository {

    ClassificacaoArquitetural salvar(ClassificacaoArquitetural classificacao);

    Optional<ClassificacaoArquitetural> buscarPorId(UUID id);

    List<ClassificacaoArquitetural> listarPorArquiteturaId(UUID arquiteturaId);

    List<UUID> listarSistemaIdsClassificados();
}
