package br.gov.empresa.arquitetura.interfaces.rest;

import br.gov.empresa.arquitetura.application.usecase.sistema.CadastrarSistemaUseCase;
import br.gov.empresa.arquitetura.application.usecase.sistema.ConsultarSistemaUseCase;
import br.gov.empresa.arquitetura.domain.model.SistemaCorporativo;
import br.gov.empresa.arquitetura.interfaces.dto.request.CadastrarSistemaRequest;
import br.gov.empresa.arquitetura.interfaces.dto.response.SistemaCorporativoResponse;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import java.net.URI;
import java.util.List;
import java.util.UUID;

@Path("/api/v1/sistemas")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Tag(name = "Sistemas Corporativos", description = "Gestão de sistemas corporativos")
public class SistemaCorporativoResource {

    @Inject CadastrarSistemaUseCase cadastrarUseCase;
    @Inject ConsultarSistemaUseCase consultarUseCase;

    @POST
    @Operation(summary = "Cadastrar sistema corporativo")
    public Response cadastrar(@Valid CadastrarSistemaRequest request) {
        SistemaCorporativo sistema = toSistema(request);
        SistemaCorporativo criado = cadastrarUseCase.executar(sistema);
        return Response.created(URI.create("/api/v1/sistemas/" + criado.getId()))
                .entity(SistemaCorporativoResponse.from(criado))
                .build();
    }

    @GET
    @Operation(summary = "Listar todos os sistemas corporativos")
    public List<SistemaCorporativoResponse> listar() {
        return consultarUseCase.listarTodos().stream().map(SistemaCorporativoResponse::from).toList();
    }

    @GET
    @Path("/{id}")
    @Operation(summary = "Consultar sistema corporativo por ID")
    public SistemaCorporativoResponse consultar(@PathParam("id") UUID id) {
        return SistemaCorporativoResponse.from(consultarUseCase.buscarPorId(id));
    }

    @GET
    @Path("/sem-classificacao")
    @Operation(summary = "Listar sistemas sem classificação arquitetural")
    public List<SistemaCorporativoResponse> listarSemClassificacao() {
        return consultarUseCase.listarSemClassificacao().stream()
                .map(SistemaCorporativoResponse::from)
                .toList();
    }

    private SistemaCorporativo toSistema(CadastrarSistemaRequest request) {
        SistemaCorporativo s = new SistemaCorporativo();
        s.setNome(request.nome());
        s.setSigla(request.sigla());
        s.setAreaResponsavel(request.areaResponsavel());
        s.setCriticidade(request.criticidade());
        s.setArquiteturaAtual(request.arquiteturaAtual());
        return s;
    }
}
