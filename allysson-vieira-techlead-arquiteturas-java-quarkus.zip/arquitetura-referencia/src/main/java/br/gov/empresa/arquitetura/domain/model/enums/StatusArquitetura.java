package br.gov.empresa.arquitetura.domain.model.enums;

public enum StatusArquitetura {
    ATIVA,
    INATIVA
}
