package br.gov.empresa.arquitetura.domain.model.enums;

public enum StatusSistema {
    ATIVO,
    INATIVO,
    EM_DESCONTINUACAO
}
