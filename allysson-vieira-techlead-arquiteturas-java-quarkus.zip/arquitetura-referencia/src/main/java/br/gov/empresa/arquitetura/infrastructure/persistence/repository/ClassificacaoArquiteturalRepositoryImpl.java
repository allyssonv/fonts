package br.gov.empresa.arquitetura.infrastructure.persistence.repository;

import br.gov.empresa.arquitetura.domain.model.ClassificacaoArquitetural;
import br.gov.empresa.arquitetura.domain.repository.ClassificacaoArquiteturalRepository;
import br.gov.empresa.arquitetura.infrastructure.persistence.entity.ClassificacaoArquiteturalEntity;
import br.gov.empresa.arquitetura.infrastructure.persistence.mapper.ClassificacaoArquiteturalMapper;
import io.quarkus.hibernate.orm.panache.PanacheRepositoryBase;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@ApplicationScoped
public class ClassificacaoArquiteturalRepositoryImpl
        implements ClassificacaoArquiteturalRepository, PanacheRepositoryBase<ClassificacaoArquiteturalEntity, UUID> {

    @Inject
    ClassificacaoArquiteturalMapper mapper;

    @Override
    @Transactional
    public ClassificacaoArquitetural salvar(ClassificacaoArquitetural classificacao) {
        ClassificacaoArquiteturalEntity entity = mapper.toEntity(classificacao);
        if (entity.getId() == null) {
            persist(entity);
        } else {
            entity = getEntityManager().merge(entity);
        }
        return mapper.toDomain(entity);
    }

    @Override
    public Optional<ClassificacaoArquitetural> buscarPorId(UUID id) {
        return findByIdOptional(id).map(mapper::toDomain);
    }

    @Override
    public List<ClassificacaoArquitetural> listarPorArquiteturaId(UUID arquiteturaId) {
        return find("arquiteturaId", arquiteturaId).stream().map(mapper::toDomain).toList();
    }

    @Override
    public List<UUID> listarSistemaIdsClassificados() {
        return listAll().stream().map(ClassificacaoArquiteturalEntity::getSistemaId).distinct().toList();
    }
}
