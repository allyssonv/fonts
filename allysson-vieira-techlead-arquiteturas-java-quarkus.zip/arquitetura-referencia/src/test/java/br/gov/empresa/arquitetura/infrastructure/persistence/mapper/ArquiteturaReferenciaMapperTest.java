package br.gov.empresa.arquitetura.infrastructure.persistence.mapper;

import br.gov.empresa.arquitetura.domain.model.ArquiteturaReferencia;
import br.gov.empresa.arquitetura.domain.model.Tecnologia;
import br.gov.empresa.arquitetura.domain.model.enums.SituacaoUso;
import br.gov.empresa.arquitetura.domain.model.enums.StatusArquitetura;
import br.gov.empresa.arquitetura.domain.model.enums.TipoArquitetura;
import br.gov.empresa.arquitetura.infrastructure.persistence.entity.ArquiteturaReferenciaEntity;
import br.gov.empresa.arquitetura.infrastructure.persistence.entity.TecnologiaEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

class ArquiteturaReferenciaMapperTest {

    ArquiteturaReferenciaMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new ArquiteturaReferenciaMapper();
    }

    @Test
    void deveMappearEntityParaDomain() {
        ArquiteturaReferenciaEntity entity = criarEntity();

        ArquiteturaReferencia domain = mapper.toDomain(entity);

        assertThat(domain).isNotNull();
        assertThat(domain.getId()).isEqualTo(entity.getId());
        assertThat(domain.getNome()).isEqualTo("Microsserviços");
        assertThat(domain.getDescricao()).isEqualTo("Descrição");
        assertThat(domain.getTipo()).isEqualTo(TipoArquitetura.MICROSSERVICOS);
        assertThat(domain.getStatus()).isEqualTo(StatusArquitetura.ATIVA);
        assertThat(domain.getDataCriacao()).isNotNull();
        assertThat(domain.getDataAtualizacao()).isNotNull();
        assertThat(domain.getTecnologiasRecomendadas()).hasSize(1);
        assertThat(domain.getTecnologiasRecomendadas().get(0).getNome()).isEqualTo("Java");
    }

    @Test
    void deveMappearDomainParaEntity() {
        ArquiteturaReferencia domain = criarDomain();

        ArquiteturaReferenciaEntity entity = mapper.toEntity(domain);

        assertThat(entity).isNotNull();
        assertThat(entity.getId()).isEqualTo(domain.getId());
        assertThat(entity.getNome()).isEqualTo("Microsserviços");
        assertThat(entity.getTipo()).isEqualTo(TipoArquitetura.MICROSSERVICOS);
        assertThat(entity.getStatus()).isEqualTo(StatusArquitetura.ATIVA);
        assertThat(entity.getTecnologiasRecomendadas()).hasSize(1);
        assertThat(entity.getTecnologiasRecomendadas().get(0).getArquitetura()).isEqualTo(entity);
    }

    @Test
    void deveRetornarNullParaEntityNula() {
        assertThat(mapper.toDomain(null)).isNull();
    }

    @Test
    void deveRetornarNullParaDomainNulo() {
        assertThat(mapper.toEntity(null)).isNull();
    }

    @Test
    void deveMappearSemTecnologias() {
        ArquiteturaReferenciaEntity entity = criarEntity();
        entity.setTecnologiasRecomendadas(null);

        ArquiteturaReferencia domain = mapper.toDomain(entity);

        assertThat(domain.getTecnologiasRecomendadas()).isEmpty();
    }

    private ArquiteturaReferenciaEntity criarEntity() {
        ArquiteturaReferenciaEntity entity = new ArquiteturaReferenciaEntity();
        entity.setId(UUID.randomUUID());
        entity.setNome("Microsserviços");
        entity.setDescricao("Descrição");
        entity.setTipo(TipoArquitetura.MICROSSERVICOS);
        entity.setStatus(StatusArquitetura.ATIVA);
        entity.setDataCriacao(LocalDateTime.now());
        entity.setDataAtualizacao(LocalDateTime.now());

        TecnologiaEntity tec = new TecnologiaEntity();
        tec.setId(UUID.randomUUID());
        tec.setNome("Java");
        tec.setCategoria("Linguagem");
        tec.setVersaoRecomendada("25");
        tec.setSituacaoUso(SituacaoUso.RECOMENDADA);
        tec.setObservacoes("obs");
        tec.setArquitetura(entity);
        entity.setTecnologiasRecomendadas(List.of(tec));

        return entity;
    }

    private ArquiteturaReferencia criarDomain() {
        ArquiteturaReferencia domain = new ArquiteturaReferencia();
        domain.setId(UUID.randomUUID());
        domain.setNome("Microsserviços");
        domain.setDescricao("Descrição");
        domain.setTipo(TipoArquitetura.MICROSSERVICOS);
        domain.setStatus(StatusArquitetura.ATIVA);
        domain.setDataCriacao(LocalDateTime.now());
        domain.setDataAtualizacao(LocalDateTime.now());

        Tecnologia tec = new Tecnologia(UUID.randomUUID(), "Java", "Linguagem", "25",
                SituacaoUso.RECOMENDADA, "obs");
        domain.setTecnologiasRecomendadas(List.of(tec));

        return domain;
    }
}
