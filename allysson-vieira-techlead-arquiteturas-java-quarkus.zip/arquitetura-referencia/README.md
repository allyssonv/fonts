# API de Controle de Arquiteturas de Referência

API REST para gestão de arquiteturas de referência corporativas e classificação arquitetural de sistemas, desenvolvida como desafio técnico para o processo seletivo de Tech Lead do Capítulo de Codificação.

---

## Tecnologias

| Tecnologia | Versão |
|---|---|
| Java | 25 |
| Quarkus | 3.36.1 |
| Maven Wrapper | incluído |
| Hibernate ORM + Panache | via Quarkus BOM |
| H2 (in-memory) | via Quarkus BOM |
| SmallRye OpenAPI | via Quarkus BOM |
| JUnit 5 + Mockito | via Quarkus BOM |
| JaCoCo | 0.8.12 |

---

## Como executar a aplicação

```bash
./mvnw quarkus:dev
```

A aplicação estará disponível em `http://localhost:8080`.

Para executar em modo normal (sem live reload):

```bash
./mvnw package
java -jar target/quarkus-app/quarkus-run.jar
```

---

## Como executar os testes

```bash
# Apenas testes unitários
./mvnw test

# Testes unitários + integração + relatório de cobertura
./mvnw verify
```

---

## Relatório de cobertura (JaCoCo)

```bash
./mvnw verify
```

O relatório HTML é gerado em:

```
target/site/jacoco/index.html
```

**Cobertura obtida:** **97.2%** de instruções (1555 cobertas / 1599 total).

O plugin JaCoCo está configurado no `pom.xml` com threshold mínimo de 90% — o build falha caso a cobertura não seja atingida.

Classes excluídas do check (razão técnica — JPA entities e repositórios Panache são carregados pelo classloader do Quarkus durante @QuarkusTest, fora do alcance do agente JaCoCo, mas são exercitados pelos testes de integração):
- `infrastructure/persistence/entity/**`
- `infrastructure/persistence/repository/**`
- `interfaces/exception/GlobalExceptionHandler.class` (classe externa sem instância)

---
## UI welcome page
```
http://localhost:8080/q/dev-ui/welcome
```

---

## Modelo de dados (H2)

Tabelas geradas pelo Hibernate ao iniciar a aplicação (`drop-and-create`).

### `ARQUITETURA_REFERENCIA`
| Coluna | Tipo | Nullable |
|---|---|---|
| `ID` | UUID | NOT NULL |
| `NOME` | VARCHAR(255) | NOT NULL |
| `DESCRICAO` | TEXT | YES |
| `TIPO` | ENUM | NOT NULL |
| `STATUS` | ENUM | NOT NULL |
| `DATACRIACAO` | TIMESTAMP | NOT NULL |
| `DATAATUALIZACAO` | TIMESTAMP | YES |

### `TECNOLOGIA`
| Coluna | Tipo | Nullable |
|---|---|---|
| `ID` | UUID | NOT NULL |
| `NOME` | VARCHAR(255) | NOT NULL |
| `CATEGORIA` | VARCHAR(255) | YES |
| `VERSAORECOMENDADA` | VARCHAR(255) | YES |
| `SITUACAOUSO` | ENUM | YES |
| `OBSERVACOES` | TEXT | YES |
| `ARQUITETURA_ID` | UUID (FK → ARQUITETURA_REFERENCIA) | YES |

### `SISTEMA_CORPORATIVO`
| Coluna | Tipo | Nullable |
|---|---|---|
| `ID` | UUID | NOT NULL |
| `NOME` | VARCHAR(255) | NOT NULL |
| `SIGLA` | VARCHAR(255) | NOT NULL |
| `AREARESPONSAVEL` | VARCHAR(255) | YES |
| `CRITICIDADE` | ENUM | NOT NULL |
| `STATUS` | ENUM | NOT NULL |
| `ARQUITETURAATUAL` | VARCHAR(255) | YES |
| `DATACRIACAO` | TIMESTAMP | NOT NULL |
| `DATAATUALIZACAO` | TIMESTAMP | YES |

### `CLASSIFICACAO_ARQUITETURAL`
| Coluna | Tipo | Nullable |
|---|---|---|
| `ID` | UUID | NOT NULL |
| `SISTEMA_ID` | UUID (FK → SISTEMA_CORPORATIVO) | NOT NULL |
| `ARQUITETURA_ID` | UUID (FK → ARQUITETURA_REFERENCIA) | NOT NULL |
| `NIVELADERENCIA` | ENUM | NOT NULL |
| `JUSTIFICATIVA` | TEXT | YES |
| `RESPONSAVELAVALIACAO` | VARCHAR(255) | NOT NULL |
| `DATAAVALIACAO` | TIMESTAMP | NOT NULL |

---

## Acesso ao Swagger / OpenAPI

Com a aplicação em execução:

- **Swagger UI:** http://localhost:8080/swagger-ui
- **OpenAPI YAML:** http://localhost:8080/q/openapi

---

## Endpoints disponíveis

### Arquiteturas de Referência

| Método | Path | Descrição |
|---|---|---|
| POST | `/api/v1/arquiteturas` | Cadastrar arquitetura |
| GET | `/api/v1/arquiteturas` | Listar todas |
| GET | `/api/v1/arquiteturas/{id}` | Consultar por ID |
| PATCH | `/api/v1/arquiteturas/{id}/inativar` | Inativar arquitetura |
| GET | `/api/v1/arquiteturas/{id}/sistemas` | Listar sistemas classificados |

### Sistemas Corporativos

| Método | Path | Descrição |
|---|---|---|
| POST | `/api/v1/sistemas` | Cadastrar sistema |
| GET | `/api/v1/sistemas` | Listar todos |
| GET | `/api/v1/sistemas/{id}` | Consultar por ID |
| GET | `/api/v1/sistemas/sem-classificacao` | Sistemas sem classificação |

### Classificações Arquiteturais

| Método | Path | Descrição |
|---|---|---|
| POST | `/api/v1/classificacoes` | Classificar sistema em arquitetura |
| PUT | `/api/v1/classificacoes/{id}` | Atualizar classificação |

---

## Arquitetura da solução (DDD)

A solução foi estruturada em quatro camadas seguindo os princípios de Domain-Driven Design:

### `domain`
Núcleo da aplicação, sem dependências de frameworks.
- **Entidades de domínio:** `ArquiteturaReferencia` (aggregate root), `SistemaCorporativo` (aggregate root), `ClassificacaoArquitetural`, `Tecnologia`
- **Enums de domínio:** `NivelAderencia`, `TipoArquitetura`, `StatusArquitetura`, `StatusSistema`, `Criticidade`, `SituacaoUso`
- **Interfaces de repositório:** definem contratos sem acoplamento à infraestrutura
- **Exceções de domínio:** `RecursoNaoEncontradoException`, `ConflitoUnicidadeException`, `RegraDeNegocioException`

### `application`
Orquestra o domínio. Cada use case tem responsabilidade única (S do SOLID).
- `CadastrarArquiteturaUseCase`, `ConsultarArquiteturaUseCase`, `ListarArquiteturasUseCase`, `InativarArquiteturaUseCase`
- `CadastrarSistemaUseCase`, `ConsultarSistemaUseCase`
- `ClassificarSistemaUseCase`, `AtualizarClassificacaoUseCase`, `ConsultarSistemasPorArquiteturaUseCase`

### `infrastructure`
Implementa os contratos do domínio usando Hibernate ORM + Panache e H2.
- Entidades JPA (`*Entity`) separadas das entidades de domínio
- Implementações de repositório (`*RepositoryImpl`) que estendem `PanacheRepositoryBase`
- Mappers isolam a conversão entre domínio e infraestrutura

### `interfaces`
Adaptadores de entrada REST. Não contêm regras de negócio.
- Resources JAX-RS com anotações OpenAPI
- DTOs imutáveis com Java Records
- `GlobalExceptionHandler` converte exceções de domínio em respostas HTTP (400 / 404 / 409)

---

## Aplicação dos princípios SOLID

| Princípio | Como foi aplicado |
|---|---|
| **S — Single Responsibility** | Cada use case executa uma única operação. Mappers isolam a responsabilidade de conversão. Resources apenas delegam para use cases. |
| **O — Open/Closed** | Novos níveis de aderência são adicionados via enum sem alteração dos use cases. Novos tipos de arquitetura seguem o mesmo padrão. |
| **L — Liskov Substitution** | As implementações de repositório (`*RepositoryImpl`) substituem as interfaces sem quebrar nenhum contrato assumido pelos use cases. |
| **I — Interface Segregation** | Três interfaces de repositório distintas, uma por agregado. Nenhum consumidor é forçado a depender de métodos que não usa. |
| **D — Dependency Inversion** | Os use cases dependem de abstrações (`ArquiteturaReferenciaRepository`, etc.). O Quarkus CDI injeta as implementações concretas em runtime. |

---

## Regras de negócio implementadas

| Regra | Comportamento |
|---|---|
| Nome único por arquitetura ativa | HTTP 409 ao tentar cadastrar nome duplicado |
| Sigla única por sistema | HTTP 409 ao tentar cadastrar sigla duplicada |
| Classificação somente em arquitetura ativa | HTTP 400 ao tentar classificar em arquitetura inativa |
| Justificativa obrigatória | HTTP 400 para `PARCIALMENTE_ADERENTE` ou `NAO_ADERENTE` sem justificativa |
| Histórico preservado | `dataAvaliacao` e `responsavelAvaliacao` são atualizados a cada modificação |
| Arquitetura inativa | Preserva histórico; bloqueia novas classificações |

---

## Premissas adotadas

1. **Uma classificação por sistema por arquitetura:** a API permite múltiplas classificações do mesmo sistema em arquiteturas diferentes, mas não valida duplicidade (requisito não especificado). A regra de unicidade pode ser adicionada como melhoria futura.
2. **Tecnologias como filhos do agregado:** `Tecnologia` é tratada como entidade filho de `ArquiteturaReferencia`, salva em cascata. Não há endpoint separado de CRUD para tecnologias.
3. **Banco H2 in-memory:** a base é recriada a cada inicialização (`drop-and-create`). Para ambiente produtivo, a estratégia seria `validate` com migrations Flyway/Liquibase.
4. **Autenticação/autorização:** fora do escopo do desafio.

---

## Como a solução poderia evoluir para governança arquitetural corporativa real

1. **Versionamento de classificações:** manter histórico completo de todas as avaliações de um sistema ao longo do tempo (tabela de histórico imutável).
2. **Relatórios de aderência:** dashboard agregando o nível de conformidade por área, tipo de arquitetura e período.
3. **Integração com repositório de ativos:** conectar ao catálogo de serviços da empresa para enriquecer dados automaticamente.
4. **Fluxo de aprovação:** classificações críticas podem exigir revisão e aprovação de um comitê de arquitetura.
5. **Notificações:** alertar áreas responsáveis quando um sistema é classificado como `NAO_ADERENTE`.
6. **Migração para banco relacional persistente:** PostgreSQL com Flyway para migrations controladas.
7. **Event sourcing:** registrar cada mudança de estado como um evento imutável, garantindo auditabilidade completa.

---

## Estrutura do projeto

```
src/
  main/java/br/gov/empresa/arquitetura/
    domain/            ← Entidades, enums, interfaces de repositório, exceções
    application/       ← Use cases (orquestração do domínio)
    infrastructure/    ← JPA entities, repositórios Panache, mappers
    interfaces/        ← Resources REST, DTOs, GlobalExceptionHandler
  main/resources/
    application.properties
  test/java/br/gov/empresa/arquitetura/
    application/usecase/  ← Testes unitários com Mockito
    interfaces/rest/      ← Testes de integração com @QuarkusTest
```
