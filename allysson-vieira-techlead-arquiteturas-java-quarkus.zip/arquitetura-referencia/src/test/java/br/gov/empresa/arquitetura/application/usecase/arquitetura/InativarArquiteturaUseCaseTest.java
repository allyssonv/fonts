package br.gov.empresa.arquitetura.application.usecase.arquitetura;

import br.gov.empresa.arquitetura.domain.exception.RecursoNaoEncontradoException;
import br.gov.empresa.arquitetura.domain.exception.RegraDeNegocioException;
import br.gov.empresa.arquitetura.domain.model.ArquiteturaReferencia;
import br.gov.empresa.arquitetura.domain.model.enums.StatusArquitetura;
import br.gov.empresa.arquitetura.domain.repository.ArquiteturaReferenciaRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class InativarArquiteturaUseCaseTest {

    @Mock
    ArquiteturaReferenciaRepository repository;

    @InjectMocks
    InativarArquiteturaUseCase useCase;

    @Test
    void deveInativarArquiteturaAtiva() {
        UUID id = UUID.randomUUID();
        ArquiteturaReferencia arquitetura = new ArquiteturaReferencia();
        arquitetura.setId(id);
        arquitetura.setStatus(StatusArquitetura.ATIVA);
        when(repository.buscarPorId(id)).thenReturn(Optional.of(arquitetura));
        when(repository.salvar(any())).thenAnswer(inv -> inv.getArgument(0));

        ArquiteturaReferencia resultado = useCase.executar(id);

        assertThat(resultado.getStatus()).isEqualTo(StatusArquitetura.INATIVA);
    }

    @Test
    void deveLancarExcecaoQuandoJaInativa() {
        UUID id = UUID.randomUUID();
        ArquiteturaReferencia arquitetura = new ArquiteturaReferencia();
        arquitetura.setId(id);
        arquitetura.setStatus(StatusArquitetura.INATIVA);
        when(repository.buscarPorId(id)).thenReturn(Optional.of(arquitetura));

        assertThatThrownBy(() -> useCase.executar(id))
                .isInstanceOf(RegraDeNegocioException.class)
                .hasMessageContaining("já está inativa");
    }

    @Test
    void deveLancarExcecaoQuandoArquiteturaNaoEncontrada() {
        UUID id = UUID.randomUUID();
        when(repository.buscarPorId(id)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> useCase.executar(id))
                .isInstanceOf(RecursoNaoEncontradoException.class);
    }
}
