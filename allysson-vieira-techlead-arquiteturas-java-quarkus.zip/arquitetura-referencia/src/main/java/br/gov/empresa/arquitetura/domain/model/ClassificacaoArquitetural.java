package br.gov.empresa.arquitetura.domain.model;

import br.gov.empresa.arquitetura.domain.model.enums.NivelAderencia;

import java.time.LocalDateTime;
import java.util.UUID;

public class ClassificacaoArquitetural {

    private UUID id;
    private UUID sistemaId;
    private UUID arquiteturaId;
    private NivelAderencia nivelAderencia;
    private String justificativa;
    private String responsavelAvaliacao;
    private LocalDateTime dataAvaliacao;

    public ClassificacaoArquitetural() {}

    public UUID getId() { return id; }
    public UUID getSistemaId() { return sistemaId; }
    public UUID getArquiteturaId() { return arquiteturaId; }
    public NivelAderencia getNivelAderencia() { return nivelAderencia; }
    public String getJustificativa() { return justificativa; }
    public String getResponsavelAvaliacao() { return responsavelAvaliacao; }
    public LocalDateTime getDataAvaliacao() { return dataAvaliacao; }

    public void setId(UUID id) { this.id = id; }
    public void setSistemaId(UUID sistemaId) { this.sistemaId = sistemaId; }
    public void setArquiteturaId(UUID arquiteturaId) { this.arquiteturaId = arquiteturaId; }
    public void setNivelAderencia(NivelAderencia nivelAderencia) { this.nivelAderencia = nivelAderencia; }
    public void setJustificativa(String justificativa) { this.justificativa = justificativa; }
    public void setResponsavelAvaliacao(String responsavelAvaliacao) { this.responsavelAvaliacao = responsavelAvaliacao; }
    public void setDataAvaliacao(LocalDateTime dataAvaliacao) { this.dataAvaliacao = dataAvaliacao; }
}
