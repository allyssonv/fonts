package br.gov.empresa.arquitetura.application.usecase.arquitetura;

import br.gov.empresa.arquitetura.domain.model.ArquiteturaReferencia;
import br.gov.empresa.arquitetura.domain.repository.ArquiteturaReferenciaRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.List;

@ApplicationScoped
public class ListarArquiteturasUseCase {

    @Inject
    ArquiteturaReferenciaRepository repository;

    public List<ArquiteturaReferencia> executar() {
        return repository.listarTodas();
    }
}
