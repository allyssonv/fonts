package br.gov.empresa.arquitetura.interfaces.rest;

import br.gov.empresa.arquitetura.application.usecase.arquitetura.CadastrarArquiteturaUseCase;
import br.gov.empresa.arquitetura.application.usecase.arquitetura.ConsultarArquiteturaUseCase;
import br.gov.empresa.arquitetura.application.usecase.arquitetura.InativarArquiteturaUseCase;
import br.gov.empresa.arquitetura.application.usecase.arquitetura.ListarArquiteturasUseCase;
import br.gov.empresa.arquitetura.application.usecase.classificacao.ConsultarSistemasPorArquiteturaUseCase;
import br.gov.empresa.arquitetura.domain.model.ArquiteturaReferencia;
import br.gov.empresa.arquitetura.domain.model.Tecnologia;
import br.gov.empresa.arquitetura.interfaces.dto.request.CadastrarArquiteturaRequest;
import br.gov.empresa.arquitetura.interfaces.dto.request.TecnologiaRequest;
import br.gov.empresa.arquitetura.interfaces.dto.response.ArquiteturaReferenciaResponse;
import br.gov.empresa.arquitetura.interfaces.dto.response.ClassificacaoArquiteturalResponse;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import java.net.URI;
import java.util.List;
import java.util.UUID;

@Path("/api/v1/arquiteturas")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Tag(name = "Arquiteturas de Referência", description = "Gestão de arquiteturas de referência corporativas")
public class ArquiteturaReferenciaResource {

    @Inject CadastrarArquiteturaUseCase cadastrarUseCase;
    @Inject ConsultarArquiteturaUseCase consultarUseCase;
    @Inject ListarArquiteturasUseCase listarUseCase;
    @Inject InativarArquiteturaUseCase inativarUseCase;
    @Inject ConsultarSistemasPorArquiteturaUseCase sistemasPorArquiteturaUseCase;

    @POST
    @Operation(summary = "Cadastrar arquitetura de referência")
    public Response cadastrar(@Valid CadastrarArquiteturaRequest request) {
        ArquiteturaReferencia arquitetura = toArquitetura(request);
        ArquiteturaReferencia criada = cadastrarUseCase.executar(arquitetura);
        return Response.created(URI.create("/api/v1/arquiteturas/" + criada.getId()))
                .entity(ArquiteturaReferenciaResponse.from(criada))
                .build();
    }

    @GET
    @Operation(summary = "Listar todas as arquiteturas de referência")
    public List<ArquiteturaReferenciaResponse> listar() {
        return listarUseCase.executar().stream().map(ArquiteturaReferenciaResponse::from).toList();
    }

    @GET
    @Path("/{id}")
    @Operation(summary = "Consultar arquitetura de referência por ID")
    public ArquiteturaReferenciaResponse consultar(@PathParam("id") UUID id) {
        return ArquiteturaReferenciaResponse.from(consultarUseCase.executar(id));
    }

    @PATCH
    @Path("/{id}/inativar")
    @Operation(summary = "Inativar arquitetura de referência")
    public ArquiteturaReferenciaResponse inativar(@PathParam("id") UUID id) {
        return ArquiteturaReferenciaResponse.from(inativarUseCase.executar(id));
    }

    @GET
    @Path("/{id}/sistemas")
    @Operation(summary = "Listar sistemas classificados em uma arquitetura")
    public List<ClassificacaoArquiteturalResponse> listarSistemas(@PathParam("id") UUID id) {
        return sistemasPorArquiteturaUseCase.executar(id).stream()
                .map(ClassificacaoArquiteturalResponse::from)
                .toList();
    }

    private ArquiteturaReferencia toArquitetura(CadastrarArquiteturaRequest request) {
        ArquiteturaReferencia a = new ArquiteturaReferencia();
        a.setNome(request.nome());
        a.setDescricao(request.descricao());
        a.setTipo(request.tipo());

        if (request.tecnologiasRecomendadas() != null) {
            List<Tecnologia> tecnologias = request.tecnologiasRecomendadas().stream()
                    .map(this::toTecnologia)
                    .toList();
            a.setTecnologiasRecomendadas(tecnologias);
        }
        return a;
    }

    private Tecnologia toTecnologia(TecnologiaRequest r) {
        return new Tecnologia(null, r.nome(), r.categoria(), r.versaoRecomendada(), r.situacaoUso(), r.observacoes());
    }
}
