package br.gov.empresa.arquitetura.interfaces.dto.request;

import br.gov.empresa.arquitetura.domain.model.enums.TipoArquitetura;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public record CadastrarArquiteturaRequest(
        @NotBlank(message = "Nome é obrigatório")
        String nome,

        @NotBlank(message = "Descrição é obrigatória")
        String descricao,

        @NotNull(message = "Tipo é obrigatório")
        TipoArquitetura tipo,

        List<TecnologiaRequest> tecnologiasRecomendadas
) {}
