package br.gov.empresa.arquitetura.interfaces.dto.response;

import br.gov.empresa.arquitetura.domain.model.ArquiteturaReferencia;
import br.gov.empresa.arquitetura.domain.model.enums.StatusArquitetura;
import br.gov.empresa.arquitetura.domain.model.enums.TipoArquitetura;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

public record ArquiteturaReferenciaResponse(
        UUID id,
        String nome,
        String descricao,
        TipoArquitetura tipo,
        StatusArquitetura status,
        List<TecnologiaResponse> tecnologiasRecomendadas,
        LocalDateTime dataCriacao,
        LocalDateTime dataAtualizacao
) {
    public static ArquiteturaReferenciaResponse from(ArquiteturaReferencia a) {
        List<TecnologiaResponse> tecnologias = a.getTecnologiasRecomendadas() == null ? List.of() :
                a.getTecnologiasRecomendadas().stream().map(TecnologiaResponse::from).toList();

        return new ArquiteturaReferenciaResponse(a.getId(), a.getNome(), a.getDescricao(),
                a.getTipo(), a.getStatus(), tecnologias, a.getDataCriacao(), a.getDataAtualizacao());
    }
}
