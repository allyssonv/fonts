package br.gov.empresa.arquitetura.interfaces.rest;

import io.quarkus.test.junit.QuarkusTest;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

@QuarkusTest
class SistemaCorporativoResourceTest {

    @Test
    void deveCadastrarSistemaComSucesso() {
        given()
                .contentType(ContentType.JSON)
                .body("""
                        {
                            "nome": "Sistema de Pagamentos",
                            "sigla": "SIPAG01",
                            "areaResponsavel": "Financeiro",
                            "criticidade": "CRITICA"
                        }
                        """)
                .when().post("/api/v1/sistemas")
                .then()
                .statusCode(201)
                .body("id", notNullValue())
                .body("sigla", equalTo("SIPAG01"))
                .body("status", equalTo("ATIVO"));
    }

    @Test
    void deveRetornar409QuandoSiglaDuplicada() {
        String body = """
                {"nome": "Sistema X", "sigla": "SIGDUP", "areaResponsavel": "TI", "criticidade": "MEDIA"}
                """;
        given().contentType(ContentType.JSON).body(body)
                .when().post("/api/v1/sistemas").then().statusCode(201);

        given().contentType(ContentType.JSON).body(body)
                .when().post("/api/v1/sistemas").then().statusCode(409);
    }

    @Test
    void deveListarTodosSistemas() {
        given()
                .when().get("/api/v1/sistemas")
                .then()
                .statusCode(200)
                .body("$", instanceOf(java.util.List.class));
    }

    @Test
    void deveRetornar404ParaSistemaInexistente() {
        given()
                .when().get("/api/v1/sistemas/00000000-0000-0000-0000-000000000002")
                .then()
                .statusCode(404);
    }

    @Test
    void deveListarSistemasSemClassificacao() {
        given()
                .contentType(ContentType.JSON)
                .body("""
                        {"nome": "Sem Classif", "sigla": "SCLX9", "areaResponsavel": "TI", "criticidade": "BAIXA"}
                        """)
                .when().post("/api/v1/sistemas")
                .then().statusCode(201);

        given()
                .when().get("/api/v1/sistemas/sem-classificacao")
                .then()
                .statusCode(200)
                .body("$", not(empty()));
    }

    @Test
    void deveRetornar400QuandoSiglaFaltando() {
        given()
                .contentType(ContentType.JSON)
                .body("""
                        {"nome": "Sistema sem sigla", "areaResponsavel": "TI", "criticidade": "ALTA"}
                        """)
                .when().post("/api/v1/sistemas")
                .then()
                .statusCode(400);
    }
}
