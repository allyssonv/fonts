package br.gov.empresa.arquitetura.interfaces.dto.response;

import br.gov.empresa.arquitetura.domain.model.ClassificacaoArquitetural;
import br.gov.empresa.arquitetura.domain.model.enums.NivelAderencia;

import java.time.LocalDateTime;
import java.util.UUID;

public record ClassificacaoArquiteturalResponse(
        UUID id,
        UUID sistemaId,
        UUID arquiteturaId,
        NivelAderencia nivelAderencia,
        String justificativa,
        String responsavelAvaliacao,
        LocalDateTime dataAvaliacao
) {
    public static ClassificacaoArquiteturalResponse from(ClassificacaoArquitetural c) {
        return new ClassificacaoArquiteturalResponse(c.getId(), c.getSistemaId(), c.getArquiteturaId(),
                c.getNivelAderencia(), c.getJustificativa(), c.getResponsavelAvaliacao(), c.getDataAvaliacao());
    }
}
