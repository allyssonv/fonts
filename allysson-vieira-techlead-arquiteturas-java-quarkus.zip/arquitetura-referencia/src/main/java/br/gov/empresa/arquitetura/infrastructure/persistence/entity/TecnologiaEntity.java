package br.gov.empresa.arquitetura.infrastructure.persistence.entity;

import br.gov.empresa.arquitetura.domain.model.enums.SituacaoUso;
import jakarta.persistence.*;

import java.util.UUID;

@Entity
@Table(name = "tecnologia")
public class TecnologiaEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false)
    private String nome;

    private String categoria;
    private String versaoRecomendada;

    @Enumerated(EnumType.STRING)
    private SituacaoUso situacaoUso;

    @Column(columnDefinition = "TEXT")
    private String observacoes;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "arquitetura_id")
    private ArquiteturaReferenciaEntity arquitetura;

    public UUID getId() { return id; }
    public String getNome() { return nome; }
    public String getCategoria() { return categoria; }
    public String getVersaoRecomendada() { return versaoRecomendada; }
    public SituacaoUso getSituacaoUso() { return situacaoUso; }
    public String getObservacoes() { return observacoes; }
    public ArquiteturaReferenciaEntity getArquitetura() { return arquitetura; }

    public void setId(UUID id) { this.id = id; }
    public void setNome(String nome) { this.nome = nome; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public void setVersaoRecomendada(String versaoRecomendada) { this.versaoRecomendada = versaoRecomendada; }
    public void setSituacaoUso(SituacaoUso situacaoUso) { this.situacaoUso = situacaoUso; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }
    public void setArquitetura(ArquiteturaReferenciaEntity arquitetura) { this.arquitetura = arquitetura; }
}
