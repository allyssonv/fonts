package br.gov.empresa.arquitetura.application.usecase.sistema;

import br.gov.empresa.arquitetura.domain.exception.RecursoNaoEncontradoException;
import br.gov.empresa.arquitetura.domain.model.SistemaCorporativo;
import br.gov.empresa.arquitetura.domain.repository.SistemaCorporativoRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ConsultarSistemaUseCaseTest {

    @Mock
    SistemaCorporativoRepository repository;

    @InjectMocks
    ConsultarSistemaUseCase useCase;

    @Test
    void deveRetornarSistemaPorId() {
        UUID id = UUID.randomUUID();
        SistemaCorporativo sistema = new SistemaCorporativo();
        sistema.setId(id);
        sistema.setSigla("ERP");
        when(repository.buscarPorId(id)).thenReturn(Optional.of(sistema));

        SistemaCorporativo resultado = useCase.buscarPorId(id);

        assertThat(resultado.getSigla()).isEqualTo("ERP");
    }

    @Test
    void deveLancarExcecaoQuandoNaoEncontrado() {
        UUID id = UUID.randomUUID();
        when(repository.buscarPorId(id)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> useCase.buscarPorId(id))
                .isInstanceOf(RecursoNaoEncontradoException.class);
    }

    @Test
    void deveListarTodosSistemas() {
        SistemaCorporativo s1 = new SistemaCorporativo();
        s1.setSigla("S1");
        when(repository.listarTodos()).thenReturn(List.of(s1));

        List<SistemaCorporativo> resultado = useCase.listarTodos();

        assertThat(resultado).hasSize(1);
    }

    @Test
    void deveListarSistemasNaoClassificados() {
        SistemaCorporativo s = new SistemaCorporativo();
        s.setSigla("NX");
        when(repository.listarSemClassificacao()).thenReturn(List.of(s));

        List<SistemaCorporativo> resultado = useCase.listarSemClassificacao();

        assertThat(resultado).hasSize(1);
    }
}
