package br.gov.empresa.arquitetura.interfaces.dto.request;

import br.gov.empresa.arquitetura.domain.model.enums.SituacaoUso;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record TecnologiaRequest(
        @NotBlank(message = "Nome da tecnologia é obrigatório")
        String nome,

        String categoria,
        String versaoRecomendada,

        @NotNull(message = "Situação de uso é obrigatória")
        SituacaoUso situacaoUso,

        String observacoes
) {}
