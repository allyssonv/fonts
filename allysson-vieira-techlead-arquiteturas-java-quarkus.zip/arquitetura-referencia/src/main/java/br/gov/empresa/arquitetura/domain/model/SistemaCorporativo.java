package br.gov.empresa.arquitetura.domain.model;

import br.gov.empresa.arquitetura.domain.model.enums.Criticidade;
import br.gov.empresa.arquitetura.domain.model.enums.StatusSistema;

import java.time.LocalDateTime;
import java.util.UUID;

public class SistemaCorporativo {

    private UUID id;
    private String nome;
    private String sigla;
    private String areaResponsavel;
    private Criticidade criticidade;
    private StatusSistema status;
    private String arquiteturaAtual;
    private LocalDateTime dataCriacao;
    private LocalDateTime dataAtualizacao;

    public SistemaCorporativo() {}

    public UUID getId() { return id; }
    public String getNome() { return nome; }
    public String getSigla() { return sigla; }
    public String getAreaResponsavel() { return areaResponsavel; }
    public Criticidade getCriticidade() { return criticidade; }
    public StatusSistema getStatus() { return status; }
    public String getArquiteturaAtual() { return arquiteturaAtual; }
    public LocalDateTime getDataCriacao() { return dataCriacao; }
    public LocalDateTime getDataAtualizacao() { return dataAtualizacao; }

    public void setId(UUID id) { this.id = id; }
    public void setNome(String nome) { this.nome = nome; }
    public void setSigla(String sigla) { this.sigla = sigla; }
    public void setAreaResponsavel(String areaResponsavel) { this.areaResponsavel = areaResponsavel; }
    public void setCriticidade(Criticidade criticidade) { this.criticidade = criticidade; }
    public void setStatus(StatusSistema status) { this.status = status; }
    public void setArquiteturaAtual(String arquiteturaAtual) { this.arquiteturaAtual = arquiteturaAtual; }
    public void setDataCriacao(LocalDateTime dataCriacao) { this.dataCriacao = dataCriacao; }
    public void setDataAtualizacao(LocalDateTime dataAtualizacao) { this.dataAtualizacao = dataAtualizacao; }
}
